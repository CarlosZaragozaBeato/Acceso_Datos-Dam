/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cargar;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.Unmarshaller;
import model.Curso;
import model.Cursos;


/**
 *
 * @author carlo
 */
public class cargar implements cargarInterface {

    /**
     * 
     * @param ruta
     * @return
     * Método utilizado para mostrar los cursos existentes en un JList
     * en formato Seriando.
     */
    @Override
    public ArrayList<Curso> cargarCursosSeriando(String ruta) {
        ArrayList<Curso> list_recuperada = new ArrayList<Curso>();
        try {

            FileInputStream fis = new FileInputStream(ruta);
            ObjectInputStream ois = new ObjectInputStream(fis);

            list_recuperada = (ArrayList<Curso>) ois.readObject();

        } catch (FileNotFoundException ex) {
        } catch (IOException ex) {
            Logger.getLogger(cargar.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(cargar.class.getName()).log(Level.SEVERE, null, ex);
        }
        return list_recuperada;
    }

    /**
     * 
     * @param ruta
     * @return
     * Método utilizado para mostrar los cursos existentes en un JList desde
     * un archivo JSON
     */
    @Override
    public ArrayList<Curso> cargarCursosJSON(String ruta) {

        Gson mGson = new Gson();

        BufferedReader br2 = null;
        ArrayList<Curso> list_cursos = null;
        try {
            br2 = new BufferedReader(new FileReader(ruta));
            java.lang.reflect.Type tipoListaCursos = new TypeToken<ArrayList<Curso>>() {
            }.getType();
            list_cursos = mGson.fromJson(br2, tipoListaCursos);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Por favor introduzca un archivo JSON valido!!",
                    "ERROR!", JOptionPane.ERROR_MESSAGE);
        }

        return list_cursos;
    }

    /**
     * 
     * @param ruta
     * @return
     * Método utilizado para mostrar los cursos existentes en un JList
     * desde un archivo XML.
     */
    @Override
    public Cursos cargarCursosXMl(String ruta) {
   
        Cursos cursos = null;

        try {
            JAXBContext jc = JAXBContext.newInstance(Cursos.class);
            Unmarshaller um = jc.createUnmarshaller();
            cursos = (Cursos) um.unmarshal(new File(ruta));

        } catch (Exception e) {

        }

        return cursos;
    }


}
