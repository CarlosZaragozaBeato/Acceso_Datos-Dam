/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package cargar;

import java.util.ArrayList;
import model.Curso;
import model.Cursos;


/**
 *
 * @author carlo
 */
public interface cargarInterface {
    public ArrayList<Curso> cargarCursosSeriando(String ruta);
    
    public Cursos cargarCursosXMl(String ruta);

    
    public ArrayList<Curso> cargarCursosJSON(String ruta); 
}
