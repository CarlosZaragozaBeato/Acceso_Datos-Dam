/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package utilidades;

import java.util.ArrayList;
import javax.swing.DefaultListModel;
import javax.swing.table.DefaultTableModel;
import model.Curso;
import model.Grupo;
import model.Materias;

/**
 *
 * @author carlo
 */
public class utilidades {

    

    /**
     * Rellena la lista de materias
     * @param dfl
     * @param list_mtr 
     */
    public void rellenarListaMaterias(DefaultListModel dfl, ArrayList<Materias> list_mtr) {
        dfl.clear();
        for (Materias mtr : list_mtr) {
                dfl.addElement(mtr);
        }
    }
    /**
     * Rellena la lista de los grupos
     * @param dfl
     * @param list_grp 
     */
    public void rellenarListaGrupos(DefaultListModel dfl, ArrayList<Grupo> list_grp) {
        dfl.clear();
        for (Grupo grp : list_grp) {
                dfl.addElement(grp);
        }
    }
    
    /**
     * Rellena la Tabla de Grupos
     *
     * @param grp
     * @param datosGrupos
     * @param dft
     */
    public void rellenarTablaGrupos(Grupo grp, String[] datosGrupos, DefaultTableModel dft) {
        Object[] fila = new Object[datosGrupos.length];

        fila[0] = grp.getClave();
        fila[1] = grp.getNombre();
        fila[2] = grp.getCodigo_curso();

        dft.addRow(fila);
    }

    /**
     * Rellena la tabla de Materias
     *
     * @param mtr
     * @param datosMaterias
     * @param dftMaterias
     */
    public void rellenarTablaMaterias(Materias mtr, String[] datosMaterias, DefaultTableModel dftMaterias) {
        Object[] fila = new Object[datosMaterias.length];
        fila[0] = mtr.getNombre();
        fila[1] = mtr.getClave();
        fila[2] = mtr.getIso();
        fila[3] = mtr.getCodigo_curso();
        fila[4] = mtr.getDescripcion_curso();
        fila[5] = mtr.getAbreviatura_curso();
        fila[6] = mtr.getDepartamento();

        dftMaterias.addRow(fila);
    }

    /**
     * Limpia una tabla especificada
     *
     * @param tbl
     */
    public void limpiarTablaFicheros(DefaultTableModel tbl) {
        while (tbl.getRowCount() > 0) {
            tbl.removeRow(0);
        }
    }

    /**
     * 
     * @param cadena
     * @param almacenCursos
     * @return 
     */
    public Curso transformarCadenaTextoCurso(String cadena, ArrayList<Curso> almacenCursos) {

        String[] trozos = cadena.split(":");
        String[] trozos_de_los_trozos = trozos[1].split(",");

        Curso curso = null;
        for (Curso crs : almacenCursos) {
            if (crs.getCodigo_curso().equals(trozos_de_los_trozos[0])) {
                curso = crs;
            }
        }
        return curso;
    }
    
    
    public String añadirArchivoFiltrado(String cadena, String tipo){
        
        String ruta = "";
        if(cadena.length() == 0){
            
            switch(tipo){
                case "mtr":
                    ruta = "ficheros/documentos/filtradas/MateriasFiltradas.dat";
                    break;  
                case "grp":
                    ruta = "ficheros/documentos/filtradas/GruposFiltrados.dat";
                    break;   
                case "crs":
                    ruta = "ficheros/documentos/filtradas/CursosFiltradas.dat";
                    break;
                
            } 
        }else{
            ruta = "ficheros/documentos/filtradas/"+cadena+".dat";
        }
        return ruta;
    }
    
    
    
    
    
    //Rellena las tablas principales
    /**
     * Rellena la lista de cursos Y filtra los cursos por primera vez
     *
     * @param dfl
     * @param almacenCursos
     */
    public void rellenarListaCursosYFiltra(DefaultListModel dfl, ArrayList<Curso> list_cursos) {
        dfl.clear();
        list_cursos = filterList(list_cursos);
        for(int i = 0; i<list_cursos.size();i++){
                   if(!dfl.contains(list_cursos.get(i).toString())){
                   dfl.addElement(list_cursos.get(i).toString()); 
              }else{
                  list_cursos.remove(list_cursos.get(i));
              }
        }

    }
    
    
    /**
     * Rellena la lista de los cursos
     * @param dfl
     * @param list_cursos 
     */
    public void rellenarListaCursos(DefaultListModel dfl, ArrayList<Curso> list_cursos) {
        dfl.clear();
            for(int i = 0; i<list_cursos.size();i++){
                   if(!dfl.contains(list_cursos.get(i).toString())){
                   dfl.addElement(list_cursos.get(i).toString()); 
              }else if(dfl.contains(list_cursos.get(i).toString())){
                  list_cursos.remove(list_cursos.get(i));
              }
        }
        }
    
    
        /**
     * Filtra la lista de los cursos
     * @param list_cursos
     * @return 
     */
    private ArrayList<Curso>  filterList(ArrayList<Curso> list_cursos){
  
        for(int i =0; i<list_cursos.size(); i++){
                for(int j =1; j<list_cursos.size(); j++){
            
                       if(list_cursos.get(i).getCodigo_curso().equalsIgnoreCase(list_cursos.get(j).getCodigo_curso())){
                                 list_cursos.remove(list_cursos.get(j));
                       }
            } 
        }
        
        return list_cursos;
    }
    
    /**
     * Carga los grupos mediante una lista de cursos
     * @param list_curso
     * @param dftGrupos 
     */
    public void cargarGruposATravesDeLista(ArrayList<Curso> list_curso, DefaultListModel dftGrupos){
        ArrayList<Grupo> lista_grp = new ArrayList<Grupo>();
        for(Curso crs:list_curso){
            for(Grupo grp:crs.getLista_grupos()){
                           lista_grp.add(grp);
            }
        }
        for(Grupo grp:lista_grp){
            if(!dftGrupos.contains(grp.toString())){
                dftGrupos.addElement(grp.toString());
            }
        }
    }
    
    /**
     * Carga las materias a través de una lista de cursos.
     * @param list_curso
     * @param dftGrupos 
     */
    public void cargarMateriasATravesDeLista(ArrayList<Curso> list_curso, DefaultListModel dftGrupos){
        
        ArrayList<Materias> lista_mtr = new ArrayList<Materias>();
        for(Curso crs:list_curso){
           for(Materias mtr:crs.getLista_materias()){
                    lista_mtr.add(mtr);
            }
        }
        for(Materias mtr:lista_mtr){
            if(!dftGrupos.contains(mtr.toString())){
                dftGrupos.addElement(mtr.toString());
            }
        }
    }
    
}
