/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package interfaz;

import cargar.cargar;
import cargarxml.cargarXML;
import filtrar.filtrar;
import guardar.guardar;
import java.awt.Color;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Properties;
import javax.swing.DefaultListModel;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import model.Curso;
import model.Cursos;
import model.Grupo;
import model.Materias;
import utilidades.utilidades;

/**
 *
 * @author carlo
 */
public class interfaz extends javax.swing.JFrame {

    /**
     * Creates new form interfaz
     */
    //clases
    private cargarXML cargar_datos = new cargarXML();
    private utilidades utilidades = new utilidades();
    private filtrar filtrar = new filtrar();
    private guardar grd = new guardar();
    private cargar cargar = new cargar();
    /**
     * Almacenes de datos
     */
    ArrayList<Curso> almacenCursos = new ArrayList();
    ArrayList<Grupo> almacenGrupos = new ArrayList();
    ArrayList<Materias> almacenMaterias = new ArrayList();

    /*Almacen materias documento seriando*/
    ArrayList<Curso> almacenCursosSeriando = new ArrayList();
    /**
     * Almacenes Filtrados
     */
    ArrayList<Curso> almacenCursosFiltrados = new ArrayList();
    ArrayList<Grupo> almacenGruposFiltrados = new ArrayList();
    ArrayList<Materias> almacenMateriasFiltrados = new ArrayList();

    private String filtrarCursos = "CodigoCursos";
    private String filtrarGrupos = "ClaveGrupos";
    private String filtrarMaterias = "NombreMaterias";

    private String rutaXML = "ficheros/documentos/principal/ExportacionGRUPOS-MATERIAS.xml";

    private String rutaCurso = "ficheros/documentos/principal/cursos.dat";
    private String rutaXml_Json = "ficheros/documentos/creados/";

    /**
     * Recursos Graficos
     */
    //* Grupos
    private String[] datosGrupos = {"Clave", "Nombre", "Codigo del curso"};
    Object[][] dataGrupos = new Object[0][0];
    private DefaultTableModel dftGrupos = new DefaultTableModel(dataGrupos, datosGrupos);

    //* Materias
    private String[] datosMaterias = {"Nombre", "Clave", "ISO", "Codigo del curso", "Descripción del curso", "Abreviatura del curso", "Departamento"};
    Object[][] dataMaterias = new Object[0][0];
    private DefaultTableModel dftMaterias = new DefaultTableModel(dataMaterias, datosMaterias);

    //*Cursos
    private DefaultListModel dflCursos = new DefaultListModel();

    /*Variables Dialogo Cursos*/
    private DefaultListModel dfl_dialogo_cursos = new DefaultListModel();
    private DefaultListModel dfl_dialogo_grupos_cursos = new DefaultListModel();
    private DefaultListModel dfl_dialogo_materias_cursos = new DefaultListModel();
    private DefaultListModel dfl_dialogo_grupos_seleccionados = new DefaultListModel();
    private DefaultListModel dfl_dialogo_materias_seleccionados = new DefaultListModel();

    private Curso cursoSeleccionado;

    /*Variables Dialogo Grupos*/
    private DefaultListModel dfl_dialogo_grupos = new DefaultListModel();
    private Grupo grupoSeleccionado;

    /*Variables Dialogo Materias*/
    private DefaultListModel dfl_dialogo_materias = new DefaultListModel();
    private Materias materiaSeleccionada;

    /*Archivo Configuracion*/
    Properties configuracion = new Properties();
    private String usuario;
    private String rutaGuardarArchivoXML;
    private String rutaGuardarArchivoJSON;
    private String tema;

    /*Variables Dialogo Cargar*/
    private DefaultListModel dfl_dialogo_cargar_cursos = new DefaultListModel();
    private DefaultListModel dfl_dialogo_cargar_grupos = new DefaultListModel();
    private DefaultListModel dfl_dialogo_cargar_materias = new DefaultListModel();
    private String currentLoad = "";

    public interfaz() {
        initComponents();
        this.setExtendedState(MAXIMIZED_BOTH);
        dialogo_cursos.setTitle("Administrador de Cursos");
        dialogo_grupos.setTitle("Administrador de Grupos");
        dialogo_materias.setTitle("Administrador de Materias");
        dialogo_propiedades.setTitle("Propiedades del proyecto");
        dialogo_cargar.setTitle("Mostrar datos de archivos");
       
        recuperarMaterias();
        recuperarGrupos();
        recuperarCursos();

        tbl_grupos.setModel(dftGrupos);
        tbl_materias.setModel(dftMaterias);
        list_cursos.setModel(dflCursos);

        rellenarTablas_Vistas();


        /*Radio Buttons filtrar Cursos*/
        bg_filtrar_curso.add(rb_filtrar_abreviatura_curso);
        bg_filtrar_curso.add(rb_filtrar_codigo_curso);
        bg_filtrar_curso.add(rb_filtrar_descripcion_curso);
        rb_filtrar_codigo_curso.setSelected(true);

        /*Radio Buttons filtrar Grupos*/
        bg_filtrar_grupos.add(rb_filtrar_grupos_clave);
        bg_filtrar_grupos.add(rb_filtrar_grupos_codigo_curso);
        bg_filtrar_grupos.add(rb_filtrar_grupos_nombre);
        rb_filtrar_grupos_clave.setSelected(true);

        /*Radio Buttons filtrar Materias*/
        bg_filtrar_materias.add(rb_iso_materias);
        bg_filtrar_materias.add(rb_grupo_materias);
        bg_filtrar_materias.add(rb_nombre_materias);
        bg_filtrar_materias.add(rb_departamento_materias);
        rb_nombre_materias.setSelected(true);

        /*Guardar Archivos Seriando*/
        grd.GuardarCursos(rutaCurso, almacenCursos);

        /*Dialogo Cursos*/
        list_dialogo_cursos.setModel(dfl_dialogo_cursos);
        list_dialogo_grupos_cursos.setModel(dfl_dialogo_grupos);
        list_dialogo_materias_cursos.setModel(dfl_dialogo_materias_cursos);
        list_dialogo_grupos_seleccionados.setModel(dfl_dialogo_grupos_seleccionados);
        list_dialogo_materias_seleccionados.setModel(dfl_dialogo_materias_seleccionados);

        utilidades.rellenarListaCursos(dfl_dialogo_cursos, almacenCursos);
        utilidades.rellenarListaGrupos(dfl_dialogo_grupos, almacenGrupos);
        utilidades.rellenarListaMaterias(dfl_dialogo_materias_cursos, almacenMaterias);

        /*Dialogo Grupos*/
        list_dialogo_grupos.setModel(dfl_dialogo_grupos);
        utilidades.rellenarListaGrupos(dfl_dialogo_grupos, almacenGrupos);

        /*Dialogo Materias*/
        list_dialogo_materias.setModel(dfl_dialogo_materias);
        utilidades.rellenarListaMaterias(dfl_dialogo_materias, almacenMaterias);

        /*Dialogo Propiedades*/
        rb_theme.add(rb_tema_claro);
        rb_theme.add(rb_tema_oscuro);
        rb_tema_claro.setSelected(true);

        /*Dialogo Configuracion*/
        cargarArchivoPropiedades();

        this.setTitle("Nombre Usuario: ".concat(usuario));

        /*Dialogo Cargar*/
        list_cargar_cursos.setModel(dfl_dialogo_cargar_cursos);
        list_cargar_grupos.setModel(dfl_dialogo_cargar_grupos);
        list_cargar_materias.setModel(dfl_dialogo_cargar_materias);
    }

    /**
     * Recupera toda la informacion de las materias
     */
    private void recuperarMaterias() {
        almacenMaterias = cargar_datos.recuperarMaterias(rutaXML);
    }

    /**
     * Recupera toda la informacion de los grupos
     */
    private void recuperarGrupos() {
        almacenGrupos = cargar_datos.recuperarGrupos(rutaXML);
    }

    /**
     * Recupera toda la informacion de los cursos
     */
    private void recuperarCursos() {
        almacenCursos = cargar_datos.recuperarCursos(almacenMaterias);
        rellenarListaGrupos();
        rellenarListaMaterias();
    }

    /**
     * carga todos los grupos y los inserta en el array_list que hay en Curso
     */
    private void rellenarListaGrupos() {
        for (Curso crs : almacenCursos) {
            crs.setLista_grupos(cargar_datos.cargarGruposDeLosCursos(crs.getCodigo_curso(), almacenGrupos));
        }
    }

    /**
     * carga todas las materias y los inserta en el array_list que hay en Curso
     */
    private void rellenarListaMaterias() {
        for (Curso crs : almacenCursos) {
            crs.setLista_materias(cargar_datos.cargarMateriasDeLosCursos(crs.getCodigo_curso(), almacenMaterias));
        }
    }

    /**
     * Rellena las tablas y listas de la interfaz
     */
    private void rellenarTablas_Vistas() {
        utilidades.rellenarListaCursosYFiltra(dflCursos, almacenCursos);
        rellenarTablaGrupos(almacenGrupos);
        rellenarTablaMaterias(almacenMaterias);
    }

    /**
     * Rellena la tabla de grupos
     * @param lista_grupos Lista de los grupos
     */
    private void rellenarTablaGrupos(ArrayList<Grupo> lista_grupos) {
        utilidades.limpiarTablaFicheros(dftGrupos);
        for (Grupo grp : lista_grupos) {
            utilidades.rellenarTablaGrupos(grp, datosGrupos, dftGrupos);
        }
    }

    /**
     * Rellena la tabla de materias.
     * @param lista_materias Lista de materias
     */
    private void rellenarTablaMaterias(ArrayList<Materias> lista_materias) {
        utilidades.limpiarTablaFicheros(dftMaterias);
        for (Materias mtr : lista_materias) {
            utilidades.rellenarTablaMaterias(mtr, datosMaterias, dftMaterias);
        }
    }

    /**
     * Muestra la información del curso seleccionado
     * @param crs Curso seleccionado de la lista
     */
    private void mostrarInformacionCursoSeleccionado(Curso crs) {
        rellenarTablaGrupos(crs.getLista_grupos());
        rellenarTablaMaterias(crs.getLista_materias());
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane2 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        bg_filtrar_materias = new javax.swing.ButtonGroup();
        bg_filtrar_curso = new javax.swing.ButtonGroup();
        bg_filtrar_grupos = new javax.swing.ButtonGroup();
        dialogo_cursos = new javax.swing.JDialog();
        pnl_principal = new javax.swing.JPanel();
        pnl_editarCursos = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jScrollPane8 = new javax.swing.JScrollPane();
        list_dialogo_grupos_cursos = new javax.swing.JList<String>();
        btn_insertar_grupo = new javax.swing.JButton();
        btn_eliminar_grupo = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        jScrollPane9 = new javax.swing.JScrollPane();
        list_dialogo_grupos_seleccionados = new javax.swing.JList<String>();
        pnl_editarCursos2 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jScrollPane11 = new javax.swing.JScrollPane();
        list_dialogo_materias_cursos = new javax.swing.JList<String>();
        btn_insertar_materia = new javax.swing.JButton();
        btn_eliminar_materia = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        jScrollPane10 = new javax.swing.JScrollPane();
        list_dialogo_materias_seleccionados = new javax.swing.JList<String>();
        pnl_cursos = new javax.swing.JPanel();
        jScrollPane7 = new javax.swing.JScrollPane();
        list_dialogo_cursos = new javax.swing.JList<String>();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        txf_dialogo_cursos_codigo_curso = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        txf_dialogo_cursos_abreviatura = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        txf_dialogo_cursos_descripcion = new javax.swing.JTextField();
        btn_crearCurso = new javax.swing.JButton();
        btn_editarCurso = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jLabel26 = new javax.swing.JLabel();
        txf_filtrar_dialogo_cursos = new javax.swing.JTextField();
        btn_eliminarCurso = new javax.swing.JButton();
        dialogo_grupos = new javax.swing.JDialog();
        jPanel8 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane6 = new javax.swing.JScrollPane();
        list_dialogo_grupos = new javax.swing.JList<String>();
        btn_eliminarGrupo = new javax.swing.JButton();
        jPanel6 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        txf_dialogo_grupos_filtrar = new javax.swing.JTextField();
        jPanel5 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        txf_dialogo_grupos_clave = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        txf_dialogo_grupos_nombre_grupo = new javax.swing.JTextField();
        btn_crearGrupo = new javax.swing.JButton();
        btn_editarGrupo = new javax.swing.JButton();
        dialogo_materias = new javax.swing.JDialog();
        jPanel4 = new javax.swing.JPanel();
        jScrollPane12 = new javax.swing.JScrollPane();
        list_dialogo_materias = new javax.swing.JList<String>();
        jPanel7 = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        txf_dialogo_materias_nombre = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        txf_dialogo_materias_clave = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        txf_dialogo_materias_iso = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        txf_dialogo_materias_descripcion = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        txf_dialogo_materias_codigo_curso = new javax.swing.JTextField();
        jLabel16 = new javax.swing.JLabel();
        txf_dialogo_materias_abreviatura = new javax.swing.JTextField();
        jLabel17 = new javax.swing.JLabel();
        txf_dialogo_materias_departamento = new javax.swing.JTextField();
        btn_crearMateria = new javax.swing.JButton();
        btn_editarMateria = new javax.swing.JButton();
        btn_eliminarMateria = new javax.swing.JButton();
        jPanel9 = new javax.swing.JPanel();
        jLabel18 = new javax.swing.JLabel();
        txf_dialogo_materias_filtrar = new javax.swing.JTextField();
        dialogo_propiedades = new javax.swing.JDialog();
        jLabel19 = new javax.swing.JLabel();
        txf_dialogo_propiedades_nombre_fichero_xml = new javax.swing.JTextField();
        jLabel20 = new javax.swing.JLabel();
        txf_dialogo_propiedad_usuario = new javax.swing.JTextField();
        rb_tema_claro = new javax.swing.JRadioButton();
        jLabel21 = new javax.swing.JLabel();
        rb_tema_oscuro = new javax.swing.JRadioButton();
        jLabel25 = new javax.swing.JLabel();
        txf_dialogo_propiedades_nombre_fichero_json = new javax.swing.JTextField();
        btn_guardarPropiedades = new javax.swing.JButton();
        dialogo_cargar = new javax.swing.JDialog();
        lbl_cargado_actualmente = new javax.swing.JLabel();
        jPanel10 = new javax.swing.JPanel();
        jScrollPane13 = new javax.swing.JScrollPane();
        list_cargar_cursos = new javax.swing.JList<String>();
        jPanel11 = new javax.swing.JPanel();
        jScrollPane14 = new javax.swing.JScrollPane();
        list_cargar_grupos = new javax.swing.JList<String>();
        jPanel12 = new javax.swing.JPanel();
        jScrollPane15 = new javax.swing.JScrollPane();
        list_cargar_materias = new javax.swing.JList<String>();
        jMenuBar6 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        mn_item_cargar_seriando = new javax.swing.JMenuItem();
        mn_item_cargar_xml = new javax.swing.JMenuItem();
        mn_item_cargar_json = new javax.swing.JMenuItem();
        buttonGroup1 = new javax.swing.ButtonGroup();
        jRadioButton1 = new javax.swing.JRadioButton();
        rb_theme = new javax.swing.ButtonGroup();
        jScrollPane5 = new javax.swing.JScrollPane();
        principal = new javax.swing.JPanel();
        pn_cursos = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        list_cursos = new javax.swing.JList<String>();
        pn_filtrar_cursos = new javax.swing.JPanel();
        txf_filtrar_curso = new javax.swing.JTextField();
        rb_filtrar_codigo_curso = new javax.swing.JRadioButton();
        rb_filtrar_abreviatura_curso = new javax.swing.JRadioButton();
        rb_filtrar_descripcion_curso = new javax.swing.JRadioButton();
        txf_guardar_cursos_filtrados = new javax.swing.JTextField();
        btn_guardar_cursos_filtrados = new javax.swing.JButton();
        jLabel27 = new javax.swing.JLabel();
        btn_controladorCursos = new javax.swing.JButton();
        pn_grupos = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        tbl_grupos = new javax.swing.JTable();
        pn_filtrar_grupos = new javax.swing.JPanel();
        txf_filtrar_grupo = new javax.swing.JTextField();
        rb_filtrar_grupos_clave = new javax.swing.JRadioButton();
        rb_filtrar_grupos_nombre = new javax.swing.JRadioButton();
        rb_filtrar_grupos_codigo_curso = new javax.swing.JRadioButton();
        txf_guardar_grupos_filtradas = new javax.swing.JTextField();
        btn_guardar_grupos_filtrados = new javax.swing.JButton();
        jLabel29 = new javax.swing.JLabel();
        btn_controladorGrupos = new javax.swing.JButton();
        pn_materias = new javax.swing.JPanel();
        jScrollPane4 = new javax.swing.JScrollPane();
        tbl_materias = new javax.swing.JTable();
        panel = new javax.swing.JPanel();
        btn_controladorMaterias = new javax.swing.JButton();
        pn_filtrar_materias = new javax.swing.JPanel();
        rb_nombre_materias = new javax.swing.JRadioButton();
        rb_departamento_materias = new javax.swing.JRadioButton();
        rb_grupo_materias = new javax.swing.JRadioButton();
        rb_iso_materias = new javax.swing.JRadioButton();
        txf_filtrar_materias = new javax.swing.JTextField();
        txf_guardar_materias_filtradas = new javax.swing.JTextField();
        btn_guardar_materias_filtradas = new javax.swing.JButton();
        jLabel28 = new javax.swing.JLabel();
        jMenuBar2 = new javax.swing.JMenuBar();
        mn_archivo = new javax.swing.JMenu();
        mn_guardar = new javax.swing.JMenu();
        mn_guardarXML = new javax.swing.JMenuItem();
        mn_guardarJSON = new javax.swing.JMenuItem();
        mn_configuracion = new javax.swing.JMenu();
        mn_propiedades = new javax.swing.JMenuItem();
        mn_reset = new javax.swing.JMenuItem();
        mn_cargar = new javax.swing.JMenu();
        mn_about = new javax.swing.JMenu();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(jTable1);

        dialogo_cursos.setLocationByPlatform(true);
        dialogo_cursos.setMinimumSize(new java.awt.Dimension(1200, 700));
        dialogo_cursos.setResizable(false);

        pnl_editarCursos.setBorder(javax.swing.BorderFactory.createTitledBorder("Insertar o eliminar grupos del curso seleccionado"));

        jLabel5.setText("Todos los Grupos");

        list_dialogo_grupos_cursos.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jScrollPane8.setViewportView(list_dialogo_grupos_cursos);

        btn_insertar_grupo.setText("Insertar");
        btn_insertar_grupo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_insertar_grupoActionPerformed(evt);
            }
        });

        btn_eliminar_grupo.setText("Eliminar");
        btn_eliminar_grupo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_eliminar_grupoActionPerformed(evt);
            }
        });

        jLabel6.setText("Grupos del curso");

        list_dialogo_grupos_seleccionados.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jScrollPane9.setViewportView(list_dialogo_grupos_seleccionados);

        javax.swing.GroupLayout pnl_editarCursosLayout = new javax.swing.GroupLayout(pnl_editarCursos);
        pnl_editarCursos.setLayout(pnl_editarCursosLayout);
        pnl_editarCursosLayout.setHorizontalGroup(
            pnl_editarCursosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnl_editarCursosLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnl_editarCursosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(pnl_editarCursosLayout.createSequentialGroup()
                        .addComponent(jScrollPane8, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(pnl_editarCursosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btn_insertar_grupo, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_eliminar_grupo, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane9, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(pnl_editarCursosLayout.createSequentialGroup()
                        .addComponent(jLabel5)
                        .addGap(140, 140, 140)
                        .addComponent(jLabel6)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        pnl_editarCursosLayout.setVerticalGroup(
            pnl_editarCursosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnl_editarCursosLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnl_editarCursosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(jLabel6))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnl_editarCursosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnl_editarCursosLayout.createSequentialGroup()
                        .addGap(31, 31, 31)
                        .addComponent(btn_insertar_grupo)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btn_eliminar_grupo)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(pnl_editarCursosLayout.createSequentialGroup()
                        .addGroup(pnl_editarCursosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane9, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane8, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 12, Short.MAX_VALUE))))
        );

        pnl_editarCursos2.setBorder(javax.swing.BorderFactory.createTitledBorder("Insertar o eliminar materias del curso seleccionado"));

        jLabel4.setText("Todas las Materias");

        list_dialogo_materias_cursos.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jScrollPane11.setViewportView(list_dialogo_materias_cursos);

        btn_insertar_materia.setText("Insertar");
        btn_insertar_materia.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_insertar_materiaActionPerformed(evt);
            }
        });

        btn_eliminar_materia.setText("Eliminar");
        btn_eliminar_materia.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_eliminar_materiaActionPerformed(evt);
            }
        });

        jLabel7.setText("Materias del Curso Seleccionado");

        list_dialogo_materias_seleccionados.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jScrollPane10.setViewportView(list_dialogo_materias_seleccionados);

        javax.swing.GroupLayout pnl_editarCursos2Layout = new javax.swing.GroupLayout(pnl_editarCursos2);
        pnl_editarCursos2.setLayout(pnl_editarCursos2Layout);
        pnl_editarCursos2Layout.setHorizontalGroup(
            pnl_editarCursos2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnl_editarCursos2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnl_editarCursos2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4)
                    .addGroup(pnl_editarCursos2Layout.createSequentialGroup()
                        .addComponent(jScrollPane11, javax.swing.GroupLayout.PREFERRED_SIZE, 391, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(pnl_editarCursos2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btn_insertar_materia, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_eliminar_materia, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnl_editarCursos2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnl_editarCursos2Layout.createSequentialGroup()
                        .addComponent(jLabel7)
                        .addContainerGap(231, Short.MAX_VALUE))
                    .addComponent(jScrollPane10)))
        );
        pnl_editarCursos2Layout.setVerticalGroup(
            pnl_editarCursos2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnl_editarCursos2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnl_editarCursos2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(jLabel7))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnl_editarCursos2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane11, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane10, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(pnl_editarCursos2Layout.createSequentialGroup()
                        .addGap(43, 43, 43)
                        .addComponent(btn_insertar_materia)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btn_eliminar_materia)))
                .addContainerGap(12, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout pnl_principalLayout = new javax.swing.GroupLayout(pnl_principal);
        pnl_principal.setLayout(pnl_principalLayout);
        pnl_principalLayout.setHorizontalGroup(
            pnl_principalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnl_principalLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(pnl_editarCursos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(pnl_editarCursos2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        pnl_principalLayout.setVerticalGroup(
            pnl_principalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnl_principalLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(pnl_principalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(pnl_editarCursos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(pnl_editarCursos2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(94, 94, 94))
        );

        pnl_cursos.setBorder(javax.swing.BorderFactory.createTitledBorder("Cursos"));

        list_dialogo_cursos.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        list_dialogo_cursos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                list_dialogo_cursosMouseClicked(evt);
            }
        });
        jScrollPane7.setViewportView(list_dialogo_cursos);

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder("Crear o editar curso"));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel1.setText("Código:");

        txf_dialogo_cursos_codigo_curso.setMinimumSize(new java.awt.Dimension(70, 22));
        txf_dialogo_cursos_codigo_curso.setPreferredSize(new java.awt.Dimension(70, 22));
        txf_dialogo_cursos_codigo_curso.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txf_dialogo_cursos_codigo_cursoKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txf_dialogo_cursos_codigo_cursoKeyTyped(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel2.setText("Abreviatura:");

        txf_dialogo_cursos_abreviatura.setPreferredSize(new java.awt.Dimension(70, 22));
        txf_dialogo_cursos_abreviatura.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txf_dialogo_cursos_abreviaturaKeyTyped(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel3.setText("Descripción:");

        txf_dialogo_cursos_descripcion.setPreferredSize(new java.awt.Dimension(100, 22));
        txf_dialogo_cursos_descripcion.addInputMethodListener(new java.awt.event.InputMethodListener() {
            public void caretPositionChanged(java.awt.event.InputMethodEvent evt) {
            }
            public void inputMethodTextChanged(java.awt.event.InputMethodEvent evt) {
                txf_dialogo_cursos_descripcionInputMethodTextChanged(evt);
            }
        });
        txf_dialogo_cursos_descripcion.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txf_dialogo_cursos_descripcionKeyTyped(evt);
            }
        });

        btn_crearCurso.setText("Crear");
        btn_crearCurso.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_crearCursoActionPerformed(evt);
            }
        });

        btn_editarCurso.setText("Confirmar edición");
        btn_editarCurso.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_editarCursoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addComponent(jLabel1)
                            .addComponent(jLabel3))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(txf_dialogo_cursos_descripcion, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 265, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(txf_dialogo_cursos_codigo_curso, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(txf_dialogo_cursos_abreviatura, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(btn_crearCurso)
                        .addGap(18, 18, 18)
                        .addComponent(btn_editarCurso)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txf_dialogo_cursos_codigo_curso, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txf_dialogo_cursos_abreviatura, javax.swing.GroupLayout.DEFAULT_SIZE, 28, Short.MAX_VALUE)
                    .addComponent(jLabel2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txf_dialogo_cursos_descripcion, javax.swing.GroupLayout.DEFAULT_SIZE, 28, Short.MAX_VALUE)
                    .addComponent(jLabel3))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_crearCurso)
                    .addComponent(btn_editarCurso))
                .addGap(28, 28, 28))
        );

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder("Filtrar"));

        jLabel26.setText("Inserta el código del curso:");

        txf_filtrar_dialogo_cursos.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txf_filtrar_dialogo_cursosKeyReleased(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel26)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txf_filtrar_dialogo_cursos, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(24, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel26)
                    .addComponent(txf_filtrar_dialogo_cursos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(16, Short.MAX_VALUE))
        );

        btn_eliminarCurso.setText("Eliminar curso");
        btn_eliminarCurso.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_eliminarCursoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout pnl_cursosLayout = new javax.swing.GroupLayout(pnl_cursos);
        pnl_cursos.setLayout(pnl_cursosLayout);
        pnl_cursosLayout.setHorizontalGroup(
            pnl_cursosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnl_cursosLayout.createSequentialGroup()
                .addGroup(pnl_cursosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane7)
                    .addGroup(pnl_cursosLayout.createSequentialGroup()
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btn_eliminarCurso)))
                .addGap(18, 18, 18)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(57, 57, 57))
        );
        pnl_cursosLayout.setVerticalGroup(
            pnl_cursosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnl_cursosLayout.createSequentialGroup()
                .addGroup(pnl_cursosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane7))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(pnl_cursosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_eliminarCurso))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout dialogo_cursosLayout = new javax.swing.GroupLayout(dialogo_cursos.getContentPane());
        dialogo_cursos.getContentPane().setLayout(dialogo_cursosLayout);
        dialogo_cursosLayout.setHorizontalGroup(
            dialogo_cursosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pnl_principal, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, dialogo_cursosLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(pnl_cursos, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        dialogo_cursosLayout.setVerticalGroup(
            dialogo_cursosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, dialogo_cursosLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(pnl_cursos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(pnl_principal, javax.swing.GroupLayout.PREFERRED_SIZE, 229, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(177, 177, 177))
        );

        dialogo_grupos.setLocationByPlatform(true);
        dialogo_grupos.setMinimumSize(new java.awt.Dimension(600, 500));
        dialogo_grupos.setResizable(false);

        jPanel8.setPreferredSize(new java.awt.Dimension(600, 700));

        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder("Grupos"));

        list_dialogo_grupos.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        list_dialogo_grupos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                list_dialogo_gruposMouseClicked(evt);
            }
        });
        jScrollPane6.setViewportView(list_dialogo_grupos);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane6, javax.swing.GroupLayout.DEFAULT_SIZE, 187, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane6, javax.swing.GroupLayout.DEFAULT_SIZE, 192, Short.MAX_VALUE)
                .addContainerGap())
        );

        btn_eliminarGrupo.setText("Eliminar");
        btn_eliminarGrupo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_eliminarGrupoActionPerformed(evt);
            }
        });

        jPanel6.setBorder(javax.swing.BorderFactory.createTitledBorder("Filtrar"));

        jLabel10.setText("Introduce el nombre del grupo:");

        txf_dialogo_grupos_filtrar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txf_dialogo_grupos_filtrarKeyReleased(evt);
            }
        });

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel10)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txf_dialogo_grupos_filtrar, javax.swing.GroupLayout.PREFERRED_SIZE, 264, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(56, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(txf_dialogo_grupos_filtrar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(14, Short.MAX_VALUE))
        );

        jPanel5.setBorder(javax.swing.BorderFactory.createTitledBorder("Crear o editar grupos"));
        jPanel5.setPreferredSize(new java.awt.Dimension(280, 193));

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel8.setText("Clave:");

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel9.setText("Nombre:");

        btn_crearGrupo.setText("Crear");
        btn_crearGrupo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_crearGrupoActionPerformed(evt);
            }
        });

        btn_editarGrupo.setText("Confirmar edición");
        btn_editarGrupo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_editarGrupoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel9)
                            .addComponent(jLabel8))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txf_dialogo_grupos_clave, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txf_dialogo_grupos_nombre_grupo)))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(btn_crearGrupo)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btn_editarGrupo)))
                .addContainerGap(55, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(txf_dialogo_grupos_clave, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(txf_dialogo_grupos_nombre_grupo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(27, 27, 27)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_crearGrupo)
                    .addComponent(btn_editarGrupo))
                .addContainerGap(44, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(29, Short.MAX_VALUE))
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_eliminarGrupo))
                        .addGap(0, 0, Short.MAX_VALUE))))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGap(16, 16, 16)
                        .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btn_eliminarGrupo)
                .addGap(18, 18, 18)
                .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(56, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout dialogo_gruposLayout = new javax.swing.GroupLayout(dialogo_grupos.getContentPane());
        dialogo_grupos.getContentPane().setLayout(dialogo_gruposLayout);
        dialogo_gruposLayout.setHorizontalGroup(
            dialogo_gruposLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, 542, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        dialogo_gruposLayout.setVerticalGroup(
            dialogo_gruposLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        dialogo_materias.setLocationByPlatform(true);
        dialogo_materias.setMinimumSize(new java.awt.Dimension(1000, 500));
        dialogo_materias.setResizable(false);

        jPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder("Materias"));

        list_dialogo_materias.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        list_dialogo_materias.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                list_dialogo_materiasMouseClicked(evt);
            }
        });
        jScrollPane12.setViewportView(list_dialogo_materias);

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane12)
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addComponent(jScrollPane12, javax.swing.GroupLayout.DEFAULT_SIZE, 225, Short.MAX_VALUE)
                .addContainerGap())
        );

        jPanel7.setBorder(javax.swing.BorderFactory.createTitledBorder("Crear o editar materias"));

        jLabel11.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel11.setText("Nombre:");

        jLabel12.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel12.setText("Clave:");

        jLabel13.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel13.setText("Iso:");

        jLabel14.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel14.setText("Descripción:");

        jLabel15.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel15.setText("Codigo Curso:");

        jLabel16.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel16.setText("Abreviatura:");

        jLabel17.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel17.setText("Departamento:");

        txf_dialogo_materias_departamento.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txf_dialogo_materias_departamentoActionPerformed(evt);
            }
        });

        btn_crearMateria.setText("Crear");
        btn_crearMateria.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_crearMateriaActionPerformed(evt);
            }
        });

        btn_editarMateria.setText("Confirmar edición");
        btn_editarMateria.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_editarMateriaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel7Layout.createSequentialGroup()
                                .addComponent(jLabel13)
                                .addGap(35, 35, 35)
                                .addComponent(txf_dialogo_materias_iso, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel7Layout.createSequentialGroup()
                                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel11)
                                    .addComponent(jLabel12))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(txf_dialogo_materias_nombre, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txf_dialogo_materias_clave, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(23, 23, 23)
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jLabel14)
                                .addComponent(jLabel16))
                            .addComponent(jLabel15))
                        .addGap(9, 9, 9)
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txf_dialogo_materias_descripcion, javax.swing.GroupLayout.DEFAULT_SIZE, 116, Short.MAX_VALUE)
                            .addComponent(txf_dialogo_materias_abreviatura)
                            .addComponent(txf_dialogo_materias_codigo_curso)))
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addComponent(jLabel17)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txf_dialogo_materias_departamento))
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addComponent(btn_crearMateria)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btn_editarMateria)))
                .addContainerGap(36, Short.MAX_VALUE))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(11, 11, 11)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11)
                    .addComponent(txf_dialogo_materias_nombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel15)
                    .addComponent(txf_dialogo_materias_codigo_curso, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(26, 26, 26)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel12)
                    .addComponent(txf_dialogo_materias_clave, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txf_dialogo_materias_descripcion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel14))
                .addGap(18, 18, 18)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel13)
                    .addComponent(txf_dialogo_materias_iso, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel16)
                    .addComponent(txf_dialogo_materias_abreviatura, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel17)
                    .addComponent(txf_dialogo_materias_departamento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 34, Short.MAX_VALUE)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_crearMateria)
                    .addComponent(btn_editarMateria))
                .addGap(34, 34, 34))
        );

        btn_eliminarMateria.setText("Eliminar");
        btn_eliminarMateria.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_eliminarMateriaActionPerformed(evt);
            }
        });

        jPanel9.setBorder(javax.swing.BorderFactory.createTitledBorder("Filtrar"));

        jLabel18.setText("Introduce la clave de la materia:");

        txf_dialogo_materias_filtrar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txf_dialogo_materias_filtrarKeyReleased(evt);
            }
        });

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addComponent(jLabel18)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txf_dialogo_materias_filtrar, javax.swing.GroupLayout.DEFAULT_SIZE, 209, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel18)
                    .addComponent(txf_dialogo_materias_filtrar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(15, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout dialogo_materiasLayout = new javax.swing.GroupLayout(dialogo_materias.getContentPane());
        dialogo_materias.getContentPane().setLayout(dialogo_materiasLayout);
        dialogo_materiasLayout.setHorizontalGroup(
            dialogo_materiasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, dialogo_materiasLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(dialogo_materiasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jPanel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, dialogo_materiasLayout.createSequentialGroup()
                        .addComponent(btn_eliminarMateria)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(jPanel4, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        dialogo_materiasLayout.setVerticalGroup(
            dialogo_materiasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(dialogo_materiasLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(dialogo_materiasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(dialogo_materiasLayout.createSequentialGroup()
                        .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btn_eliminarMateria))
                    .addComponent(jPanel7, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(64, Short.MAX_VALUE))
        );

        dialogo_propiedades.setLocationByPlatform(true);
        dialogo_propiedades.setMinimumSize(new java.awt.Dimension(400, 300));
        dialogo_propiedades.setResizable(false);

        jLabel19.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel19.setText("Nombre de Fichero XML:");

        jLabel20.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel20.setText("Nombre Usuario:");

        rb_tema_claro.setText("Tema Claro");

        jLabel21.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel21.setText("Tema");

        rb_tema_oscuro.setText("Tema Oscuro");
        rb_tema_oscuro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rb_tema_oscuroActionPerformed(evt);
            }
        });

        jLabel25.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel25.setText("Nombre de Fichero JSON:");

        btn_guardarPropiedades.setText("Guardar");
        btn_guardarPropiedades.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btn_guardarPropiedadesMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout dialogo_propiedadesLayout = new javax.swing.GroupLayout(dialogo_propiedades.getContentPane());
        dialogo_propiedades.getContentPane().setLayout(dialogo_propiedadesLayout);
        dialogo_propiedadesLayout.setHorizontalGroup(
            dialogo_propiedadesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(dialogo_propiedadesLayout.createSequentialGroup()
                .addGroup(dialogo_propiedadesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(dialogo_propiedadesLayout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(dialogo_propiedadesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel21)
                            .addGroup(dialogo_propiedadesLayout.createSequentialGroup()
                                .addComponent(jLabel19)
                                .addGap(12, 12, 12)
                                .addComponent(txf_dialogo_propiedades_nombre_fichero_xml, javax.swing.GroupLayout.PREFERRED_SIZE, 192, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(dialogo_propiedadesLayout.createSequentialGroup()
                                .addGroup(dialogo_propiedadesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel25)
                                    .addComponent(jLabel20))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(dialogo_propiedadesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(txf_dialogo_propiedad_usuario, javax.swing.GroupLayout.DEFAULT_SIZE, 193, Short.MAX_VALUE)
                                    .addComponent(txf_dialogo_propiedades_nombre_fichero_json)))
                            .addGroup(dialogo_propiedadesLayout.createSequentialGroup()
                                .addComponent(rb_tema_claro)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(rb_tema_oscuro))))
                    .addGroup(dialogo_propiedadesLayout.createSequentialGroup()
                        .addGap(146, 146, 146)
                        .addComponent(btn_guardarPropiedades)))
                .addContainerGap(51, Short.MAX_VALUE))
        );
        dialogo_propiedadesLayout.setVerticalGroup(
            dialogo_propiedadesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(dialogo_propiedadesLayout.createSequentialGroup()
                .addGap(11, 11, 11)
                .addGroup(dialogo_propiedadesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel19)
                    .addComponent(txf_dialogo_propiedades_nombre_fichero_xml, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(dialogo_propiedadesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel25)
                    .addComponent(txf_dialogo_propiedades_nombre_fichero_json, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(dialogo_propiedadesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel20)
                    .addComponent(txf_dialogo_propiedad_usuario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel21)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(dialogo_propiedadesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(rb_tema_claro)
                    .addComponent(rb_tema_oscuro))
                .addGap(18, 18, 18)
                .addComponent(btn_guardarPropiedades)
                .addContainerGap(28, Short.MAX_VALUE))
        );

        dialogo_cargar.setLocationByPlatform(true);
        dialogo_cargar.setMinimumSize(new java.awt.Dimension(700, 550));
        dialogo_cargar.setResizable(false);

        lbl_cargado_actualmente.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lbl_cargado_actualmente.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);

        jPanel10.setBorder(javax.swing.BorderFactory.createTitledBorder("Cursos"));

        list_cargar_cursos.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jScrollPane13.setViewportView(list_cargar_cursos);

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane13)
                .addContainerGap())
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane13)
                .addContainerGap())
        );

        jPanel11.setBorder(javax.swing.BorderFactory.createTitledBorder("Grupos"));

        list_cargar_grupos.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jScrollPane14.setViewportView(list_cargar_grupos);

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane14, javax.swing.GroupLayout.DEFAULT_SIZE, 190, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane14)
        );

        jPanel12.setBorder(javax.swing.BorderFactory.createTitledBorder("Materias"));

        list_cargar_materias.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jScrollPane15.setViewportView(list_cargar_materias);

        javax.swing.GroupLayout jPanel12Layout = new javax.swing.GroupLayout(jPanel12);
        jPanel12.setLayout(jPanel12Layout);
        jPanel12Layout.setHorizontalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addComponent(jScrollPane15, javax.swing.GroupLayout.DEFAULT_SIZE, 448, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel12Layout.setVerticalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addComponent(jScrollPane15, javax.swing.GroupLayout.DEFAULT_SIZE, 152, Short.MAX_VALUE)
                .addContainerGap())
        );

        jMenu1.setText("Cargar");

        mn_item_cargar_seriando.setText("Seriando");
        mn_item_cargar_seriando.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mn_item_cargar_seriandoActionPerformed(evt);
            }
        });
        jMenu1.add(mn_item_cargar_seriando);

        mn_item_cargar_xml.setText("XML");
        mn_item_cargar_xml.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mn_item_cargar_xmlActionPerformed(evt);
            }
        });
        jMenu1.add(mn_item_cargar_xml);

        mn_item_cargar_json.setText("JSON");
        mn_item_cargar_json.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mn_item_cargar_jsonActionPerformed(evt);
            }
        });
        jMenu1.add(mn_item_cargar_json);

        jMenuBar6.add(jMenu1);

        dialogo_cargar.setJMenuBar(jMenuBar6);

        javax.swing.GroupLayout dialogo_cargarLayout = new javax.swing.GroupLayout(dialogo_cargar.getContentPane());
        dialogo_cargar.getContentPane().setLayout(dialogo_cargarLayout);
        dialogo_cargarLayout.setHorizontalGroup(
            dialogo_cargarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(dialogo_cargarLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(dialogo_cargarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(dialogo_cargarLayout.createSequentialGroup()
                        .addComponent(jPanel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jPanel12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, dialogo_cargarLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lbl_cargado_actualmente, javax.swing.GroupLayout.PREFERRED_SIZE, 255, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(220, 220, 220))
        );
        dialogo_cargarLayout.setVerticalGroup(
            dialogo_cargarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(dialogo_cargarLayout.createSequentialGroup()
                .addComponent(lbl_cargado_actualmente, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(dialogo_cargarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(116, Short.MAX_VALUE))
        );

        jRadioButton1.setText("jRadioButton1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setLocationByPlatform(true);

        principal.setPreferredSize(new java.awt.Dimension(1280, 720));

        pn_cursos.setBorder(javax.swing.BorderFactory.createTitledBorder("Cursos"));

        list_cursos.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        list_cursos.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        list_cursos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                list_cursosMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(list_cursos);

        pn_filtrar_cursos.setBorder(javax.swing.BorderFactory.createTitledBorder("Filtrar"));

        txf_filtrar_curso.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txf_filtrar_cursoKeyReleased(evt);
            }
        });

        rb_filtrar_codigo_curso.setText("Codigo Curso");
        rb_filtrar_codigo_curso.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                rb_filtrar_codigo_cursoMouseClicked(evt);
            }
        });

        rb_filtrar_abreviatura_curso.setText("Abreviatura");
        rb_filtrar_abreviatura_curso.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                rb_filtrar_abreviatura_cursoMouseClicked(evt);
            }
        });
        rb_filtrar_abreviatura_curso.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rb_filtrar_abreviatura_cursoActionPerformed(evt);
            }
        });

        rb_filtrar_descripcion_curso.setText("Descripción");
        rb_filtrar_descripcion_curso.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                rb_filtrar_descripcion_cursoMouseClicked(evt);
            }
        });
        rb_filtrar_descripcion_curso.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rb_filtrar_descripcion_cursoActionPerformed(evt);
            }
        });

        btn_guardar_cursos_filtrados.setText("Guardar Filtrados");
        btn_guardar_cursos_filtrados.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_guardar_cursos_filtradosActionPerformed(evt);
            }
        });

        jLabel27.setText("Introduce el nombre del archivo a crear:");

        javax.swing.GroupLayout pn_filtrar_cursosLayout = new javax.swing.GroupLayout(pn_filtrar_cursos);
        pn_filtrar_cursos.setLayout(pn_filtrar_cursosLayout);
        pn_filtrar_cursosLayout.setHorizontalGroup(
            pn_filtrar_cursosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pn_filtrar_cursosLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pn_filtrar_cursosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pn_filtrar_cursosLayout.createSequentialGroup()
                        .addComponent(txf_filtrar_curso, javax.swing.GroupLayout.PREFERRED_SIZE, 203, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(rb_filtrar_codigo_curso)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(rb_filtrar_abreviatura_curso)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(rb_filtrar_descripcion_curso)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(pn_filtrar_cursosLayout.createSequentialGroup()
                        .addComponent(jLabel27)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txf_guardar_cursos_filtrados)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btn_guardar_cursos_filtrados)
                        .addGap(54, 54, 54))))
        );
        pn_filtrar_cursosLayout.setVerticalGroup(
            pn_filtrar_cursosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pn_filtrar_cursosLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pn_filtrar_cursosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txf_filtrar_curso, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(rb_filtrar_descripcion_curso)
                    .addComponent(rb_filtrar_codigo_curso)
                    .addComponent(rb_filtrar_abreviatura_curso))
                .addGap(32, 32, 32)
                .addGroup(pn_filtrar_cursosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txf_guardar_cursos_filtrados, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel27)
                    .addComponent(btn_guardar_cursos_filtrados))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        btn_controladorCursos.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btn_controladorCursos.setText("Abrir administrador de Cursos");
        btn_controladorCursos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_controladorCursosActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout pn_cursosLayout = new javax.swing.GroupLayout(pn_cursos);
        pn_cursos.setLayout(pn_cursosLayout);
        pn_cursosLayout.setHorizontalGroup(
            pn_cursosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pn_cursosLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pn_cursosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(pn_filtrar_cursos, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(pn_cursosLayout.createSequentialGroup()
                        .addGroup(pn_cursosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btn_controladorCursos)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 542, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        pn_cursosLayout.setVerticalGroup(
            pn_cursosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pn_cursosLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 178, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btn_controladorCursos)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(pn_filtrar_cursos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pn_grupos.setBorder(javax.swing.BorderFactory.createTitledBorder("Grupos"));

        tbl_grupos.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        tbl_grupos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3"
            }
        ));
        tbl_grupos.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_NEXT_COLUMN);
        jScrollPane3.setViewportView(tbl_grupos);
        if (tbl_grupos.getColumnModel().getColumnCount() > 0) {
            tbl_grupos.getColumnModel().getColumn(0).setPreferredWidth(50);
            tbl_grupos.getColumnModel().getColumn(1).setPreferredWidth(50);
            tbl_grupos.getColumnModel().getColumn(2).setPreferredWidth(100);
        }

        pn_filtrar_grupos.setBorder(javax.swing.BorderFactory.createTitledBorder("Filtrar"));

        txf_filtrar_grupo.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txf_filtrar_grupoKeyReleased(evt);
            }
        });

        rb_filtrar_grupos_clave.setText("Clave");
        rb_filtrar_grupos_clave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rb_filtrar_grupos_claveActionPerformed(evt);
            }
        });

        rb_filtrar_grupos_nombre.setText("Nombre");
        rb_filtrar_grupos_nombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rb_filtrar_grupos_nombreActionPerformed(evt);
            }
        });

        rb_filtrar_grupos_codigo_curso.setText("Codigo Curso");
        rb_filtrar_grupos_codigo_curso.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rb_filtrar_grupos_codigo_cursoActionPerformed(evt);
            }
        });

        btn_guardar_grupos_filtrados.setText("Guardar Filtrados");
        btn_guardar_grupos_filtrados.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_guardar_grupos_filtradosActionPerformed(evt);
            }
        });

        jLabel29.setText("Introduce el nombre del archivo a crear:");

        javax.swing.GroupLayout pn_filtrar_gruposLayout = new javax.swing.GroupLayout(pn_filtrar_grupos);
        pn_filtrar_grupos.setLayout(pn_filtrar_gruposLayout);
        pn_filtrar_gruposLayout.setHorizontalGroup(
            pn_filtrar_gruposLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pn_filtrar_gruposLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(pn_filtrar_gruposLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(pn_filtrar_gruposLayout.createSequentialGroup()
                        .addComponent(txf_filtrar_grupo, javax.swing.GroupLayout.PREFERRED_SIZE, 275, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(rb_filtrar_grupos_clave)
                        .addGap(18, 18, 18)
                        .addComponent(rb_filtrar_grupos_nombre))
                    .addGroup(pn_filtrar_gruposLayout.createSequentialGroup()
                        .addComponent(jLabel29)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txf_guardar_grupos_filtradas)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pn_filtrar_gruposLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(rb_filtrar_grupos_codigo_curso)
                    .addComponent(btn_guardar_grupos_filtrados)))
        );
        pn_filtrar_gruposLayout.setVerticalGroup(
            pn_filtrar_gruposLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pn_filtrar_gruposLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pn_filtrar_gruposLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txf_filtrar_grupo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(rb_filtrar_grupos_clave)
                    .addComponent(rb_filtrar_grupos_nombre)
                    .addComponent(rb_filtrar_grupos_codigo_curso))
                .addGap(19, 19, 19)
                .addGroup(pn_filtrar_gruposLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel29)
                    .addComponent(txf_guardar_grupos_filtradas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_guardar_grupos_filtrados))
                .addContainerGap(19, Short.MAX_VALUE))
        );

        btn_controladorGrupos.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btn_controladorGrupos.setText("Abrir administrador de grupos");
        btn_controladorGrupos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_controladorGruposActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout pn_gruposLayout = new javax.swing.GroupLayout(pn_grupos);
        pn_grupos.setLayout(pn_gruposLayout);
        pn_gruposLayout.setHorizontalGroup(
            pn_gruposLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pn_gruposLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pn_gruposLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btn_controladorGrupos)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 531, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addComponent(pn_filtrar_grupos, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        pn_gruposLayout.setVerticalGroup(
            pn_gruposLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pn_gruposLayout.createSequentialGroup()
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 172, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(24, 24, 24)
                .addComponent(btn_controladorGrupos)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(pn_filtrar_grupos, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        pn_materias.setBorder(javax.swing.BorderFactory.createTitledBorder("Materias"));

        tbl_materias.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tbl_materias.setMaximumSize(new java.awt.Dimension(1000, 80));
        jScrollPane4.setViewportView(tbl_materias);

        btn_controladorMaterias.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btn_controladorMaterias.setText("Abrir administrador de materias");
        btn_controladorMaterias.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_controladorMateriasActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelLayout = new javax.swing.GroupLayout(panel);
        panel.setLayout(panelLayout);
        panelLayout.setHorizontalGroup(
            panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btn_controladorMaterias)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        panelLayout.setVerticalGroup(
            panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelLayout.createSequentialGroup()
                .addComponent(btn_controladorMaterias)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pn_filtrar_materias.setBorder(javax.swing.BorderFactory.createTitledBorder("Filtrar"));

        rb_nombre_materias.setText("Nombre");
        rb_nombre_materias.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                rb_nombre_materiasMouseClicked(evt);
            }
        });
        rb_nombre_materias.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rb_nombre_materiasActionPerformed(evt);
            }
        });

        rb_departamento_materias.setText("Departamento");
        rb_departamento_materias.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                rb_departamento_materiasMouseClicked(evt);
            }
        });

        rb_grupo_materias.setText("Codigo Curso");
        rb_grupo_materias.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                rb_grupo_materiasMouseClicked(evt);
            }
        });

        rb_iso_materias.setText("Iso");
        rb_iso_materias.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                rb_iso_materiasMouseClicked(evt);
            }
        });

        txf_filtrar_materias.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txf_filtrar_materiasActionPerformed(evt);
            }
        });
        txf_filtrar_materias.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txf_filtrar_materiasKeyReleased(evt);
            }
        });

        btn_guardar_materias_filtradas.setText("Guardar Filtradas");
        btn_guardar_materias_filtradas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_guardar_materias_filtradasActionPerformed(evt);
            }
        });

        jLabel28.setText("Introduce el nombre del archivo a crear:");

        javax.swing.GroupLayout pn_filtrar_materiasLayout = new javax.swing.GroupLayout(pn_filtrar_materias);
        pn_filtrar_materias.setLayout(pn_filtrar_materiasLayout);
        pn_filtrar_materiasLayout.setHorizontalGroup(
            pn_filtrar_materiasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pn_filtrar_materiasLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pn_filtrar_materiasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pn_filtrar_materiasLayout.createSequentialGroup()
                        .addComponent(jLabel28)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pn_filtrar_materiasLayout.createSequentialGroup()
                        .addGroup(pn_filtrar_materiasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(txf_filtrar_materias, javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pn_filtrar_materiasLayout.createSequentialGroup()
                                .addGroup(pn_filtrar_materiasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(txf_guardar_materias_filtradas, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(pn_filtrar_materiasLayout.createSequentialGroup()
                                        .addGap(0, 26, Short.MAX_VALUE)
                                        .addComponent(rb_nombre_materias)
                                        .addGap(18, 18, 18)
                                        .addComponent(rb_departamento_materias)
                                        .addGap(18, 18, 18)
                                        .addComponent(rb_iso_materias, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(18, 18, 18)
                                .addGroup(pn_filtrar_materiasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(rb_grupo_materias)
                                    .addComponent(btn_guardar_materias_filtradas))))
                        .addGap(141, 141, 141))))
        );
        pn_filtrar_materiasLayout.setVerticalGroup(
            pn_filtrar_materiasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pn_filtrar_materiasLayout.createSequentialGroup()
                .addGap(11, 11, 11)
                .addComponent(txf_filtrar_materias, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pn_filtrar_materiasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(rb_nombre_materias)
                    .addComponent(rb_departamento_materias)
                    .addComponent(rb_iso_materias)
                    .addComponent(rb_grupo_materias))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 18, Short.MAX_VALUE)
                .addComponent(jLabel28)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(pn_filtrar_materiasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btn_guardar_materias_filtradas)
                    .addComponent(txf_guardar_materias_filtradas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(12, 12, 12))
        );

        javax.swing.GroupLayout pn_materiasLayout = new javax.swing.GroupLayout(pn_materias);
        pn_materias.setLayout(pn_materiasLayout);
        pn_materiasLayout.setHorizontalGroup(
            pn_materiasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pn_materiasLayout.createSequentialGroup()
                .addGroup(pn_materiasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(panel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(pn_materiasLayout.createSequentialGroup()
                        .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 657, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(pn_filtrar_materias, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap())
        );
        pn_materiasLayout.setVerticalGroup(
            pn_materiasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pn_materiasLayout.createSequentialGroup()
                .addGroup(pn_materiasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addComponent(pn_filtrar_materias, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        javax.swing.GroupLayout principalLayout = new javax.swing.GroupLayout(principal);
        principal.setLayout(principalLayout);
        principalLayout.setHorizontalGroup(
            principalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(principalLayout.createSequentialGroup()
                .addGroup(principalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(principalLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(pn_cursos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(pn_grupos, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(principalLayout.createSequentialGroup()
                        .addGap(12, 12, 12)
                        .addComponent(pn_materias, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap())
        );
        principalLayout.setVerticalGroup(
            principalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(principalLayout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(principalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(pn_cursos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(pn_grupos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(pn_materias, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(97, Short.MAX_VALUE))
        );

        jScrollPane5.setViewportView(principal);

        mn_archivo.setText("Archivo");

        mn_guardar.setText("Guardar como...");

        mn_guardarXML.setText("Archivo XML");
        mn_guardarXML.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mn_guardarXMLActionPerformed(evt);
            }
        });
        mn_guardar.add(mn_guardarXML);

        mn_guardarJSON.setText("Archivo JSON");
        mn_guardarJSON.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mn_guardarJSONActionPerformed(evt);
            }
        });
        mn_guardar.add(mn_guardarJSON);

        mn_archivo.add(mn_guardar);

        mn_configuracion.setText("Configuración");

        mn_propiedades.setText("Propiedades");
        mn_propiedades.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mn_propiedadesActionPerformed(evt);
            }
        });
        mn_configuracion.add(mn_propiedades);

        mn_reset.setText("Reset");
        mn_reset.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mn_resetActionPerformed(evt);
            }
        });
        mn_configuracion.add(mn_reset);

        mn_archivo.add(mn_configuracion);

        jMenuBar2.add(mn_archivo);

        mn_cargar.setText("Cargar");
        mn_cargar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                mn_cargarMouseClicked(evt);
            }
        });
        jMenuBar2.add(mn_cargar);

        mn_about.setText("Info");
        mn_about.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                mn_aboutMouseClicked(evt);
            }
        });
        jMenuBar2.add(mn_about);

        setJMenuBar(jMenuBar2);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane5, javax.swing.GroupLayout.DEFAULT_SIZE, 1307, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 647, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void rb_nombre_materiasMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rb_nombre_materiasMouseClicked
        // TODO add your handling code here:
        if (rb_nombre_materias.isSelected()) {
            filtrarMaterias = "NombreMaterias";
        }
    }//GEN-LAST:event_rb_nombre_materiasMouseClicked

    private void rb_departamento_materiasMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rb_departamento_materiasMouseClicked
        // TODO add your handling code here:
        if (rb_departamento_materias.isSelected()) {
            filtrarMaterias = "DepartamentoMaterias";
        }
    }//GEN-LAST:event_rb_departamento_materiasMouseClicked

    private void rb_grupo_materiasMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rb_grupo_materiasMouseClicked
        // TODO add your handling code here:
        if (rb_grupo_materias.isSelected()) {
            filtrarMaterias = "CodigoMaterias";
        }
    }//GEN-LAST:event_rb_grupo_materiasMouseClicked

    private void rb_iso_materiasMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rb_iso_materiasMouseClicked
        // TODO add your handling code here:
        if (rb_iso_materias.isSelected()) {
            filtrarMaterias = "IsoMaterias";
        }
    }//GEN-LAST:event_rb_iso_materiasMouseClicked

    /**
     * Método utilizado para filtrar materias.
     * @param evt 
     */
    private void txf_filtrar_materiasKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txf_filtrar_materiasKeyReleased
        // TODO add your handling code here:
        rellenarTablaMaterias(filtrar.filtrarMaterias(txf_filtrar_materias.getText(), filtrarMaterias, almacenMaterias));
        almacenMateriasFiltrados = filtrar.filtrarMaterias(txf_filtrar_materias.getText(), filtrarMaterias, almacenMaterias);
    }//GEN-LAST:event_txf_filtrar_materiasKeyReleased

    /**
     * Método utilizado para guardar en un archivo las materias filtradas.
     * @param evt 
     */
    private void btn_guardar_materias_filtradasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_guardar_materias_filtradasActionPerformed
        // TODO add your handling code here:
        if (almacenMateriasFiltrados.size() > 0) {
            String ruta = utilidades.añadirArchivoFiltrado(txf_guardar_materias_filtradas.getText(), "mtr");

            try {
                grd.GuardarMaterias(utilidades.añadirArchivoFiltrado(txf_guardar_materias_filtradas.getText(), "mtr"), almacenMateriasFiltrados);
                JOptionPane.showMessageDialog(null, "Las materias filtradas se guardaron en " + ruta,
                        "Info!", JOptionPane.INFORMATION_MESSAGE);
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "No se han podido guardar los datos en la siguiente ruta " + ruta,
                        "ERROR!", JOptionPane.ERROR_MESSAGE);
            }
        }
    }//GEN-LAST:event_btn_guardar_materias_filtradasActionPerformed

    private void list_cursosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_list_cursosMouseClicked
        // TODO add your handling code here:
        if (list_cursos.getSelectedIndex() != -1) {
            mostrarInformacionCursoSeleccionado(utilidades.transformarCadenaTextoCurso(dflCursos.get(list_cursos.getSelectedIndex()).toString(), almacenCursos));
        }
    }//GEN-LAST:event_list_cursosMouseClicked

    /**
     * Método utilizado para filtrar los cursos.
     * @param evt 
     */
    private void txf_filtrar_cursoKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txf_filtrar_cursoKeyReleased
        // TODO add your handling code here:
        utilidades.rellenarListaCursos(dflCursos, filtrar.filtrarCursos(txf_filtrar_curso.getText(), filtrarCursos, almacenCursos));
        almacenCursosFiltrados = filtrar.filtrarCursos(txf_filtrar_curso.getText(), filtrarCursos, almacenCursos);
    }//GEN-LAST:event_txf_filtrar_cursoKeyReleased

    private void rb_filtrar_codigo_cursoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rb_filtrar_codigo_cursoMouseClicked
        // TODO add your handling code here:
        if (rb_filtrar_codigo_curso.isSelected()) {
            filtrarCursos = "CodigoCursos";
        }
    }//GEN-LAST:event_rb_filtrar_codigo_cursoMouseClicked

    private void rb_filtrar_abreviatura_cursoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rb_filtrar_abreviatura_cursoMouseClicked
        // TODO add your handling code here:
        if (rb_filtrar_abreviatura_curso.isSelected()) {
            filtrarCursos = "AbreviaturaCursos";
        }
    }//GEN-LAST:event_rb_filtrar_abreviatura_cursoMouseClicked

    private void rb_filtrar_descripcion_cursoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rb_filtrar_descripcion_cursoMouseClicked
        // TODO add your handling code here:
        if (rb_filtrar_descripcion_curso.isSelected()) {
            filtrarCursos = "DescripcionCursos";
        }
    }//GEN-LAST:event_rb_filtrar_descripcion_cursoMouseClicked

    private void txf_filtrar_materiasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txf_filtrar_materiasActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txf_filtrar_materiasActionPerformed

    private void rb_filtrar_abreviatura_cursoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rb_filtrar_abreviatura_cursoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rb_filtrar_abreviatura_cursoActionPerformed

    private void rb_filtrar_descripcion_cursoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rb_filtrar_descripcion_cursoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rb_filtrar_descripcion_cursoActionPerformed

    /**
     * Método utilizado para guardar en un archivo los cursos filtrados.
     * @param evt 
     */
    private void btn_guardar_cursos_filtradosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_guardar_cursos_filtradosActionPerformed
        // TODO add your handling code here:
        if (almacenCursosFiltrados.size() > 0) {

            String ruta = utilidades.añadirArchivoFiltrado(txf_guardar_cursos_filtrados.getText(), "crs");

            try {
                grd.GuardarCursos(utilidades.añadirArchivoFiltrado(txf_guardar_cursos_filtrados.getText(), "crs"), almacenCursosFiltrados);
                JOptionPane.showMessageDialog(null, "Las Cursos Filtrados se guardaron en " + ruta,
                        "Info!", JOptionPane.INFORMATION_MESSAGE);
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "No se han podido guardar los datos en la siguiente ruta " + ruta,
                        "ERROR!", JOptionPane.ERROR_MESSAGE);
            }
        }
    }//GEN-LAST:event_btn_guardar_cursos_filtradosActionPerformed

    private void txf_dialogo_grupos_filtrarKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txf_dialogo_grupos_filtrarKeyReleased
        // TODO add your handling code here:
        utilidades.rellenarListaGrupos(dfl_dialogo_grupos, filtrar.filtrarGrupos(txf_dialogo_grupos_filtrar.getText(), "NombreGrupos", almacenGrupos));
    }//GEN-LAST:event_txf_dialogo_grupos_filtrarKeyReleased

    private void list_dialogo_gruposMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_list_dialogo_gruposMouseClicked
        // TODO add your handling code here:
        if (list_dialogo_grupos.getSelectedIndex() != -1) {

            grupoSeleccionado = (Grupo) dfl_dialogo_grupos.get(list_dialogo_grupos.getSelectedIndex());
            rellenarParametrosGrupos();

        }
    }//GEN-LAST:event_list_dialogo_gruposMouseClicked

    private void txf_dialogo_materias_departamentoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txf_dialogo_materias_departamentoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txf_dialogo_materias_departamentoActionPerformed

    private void list_dialogo_materiasMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_list_dialogo_materiasMouseClicked
        // TODO add your handling code here:
        rellenarParametrosMaterias((Materias) dfl_dialogo_materias.get(list_dialogo_materias.getSelectedIndex()));
    }//GEN-LAST:event_list_dialogo_materiasMouseClicked

    private void txf_dialogo_materias_filtrarKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txf_dialogo_materias_filtrarKeyReleased
        // TODO add your handling code here:
        utilidades.rellenarListaMaterias(dfl_dialogo_materias, filtrar.filtrarMaterias(txf_dialogo_materias_filtrar.getText(), "CodigoMaterias", almacenMaterias));

    }//GEN-LAST:event_txf_dialogo_materias_filtrarKeyReleased

    private void rb_tema_oscuroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rb_tema_oscuroActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rb_tema_oscuroActionPerformed

    private void mn_cargarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mn_cargarMouseClicked
        // TODO add your handling code here:
        dialogo_cargar.setVisible(true);
    }//GEN-LAST:event_mn_cargarMouseClicked

    private void mn_item_cargar_seriandoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mn_item_cargar_seriandoActionPerformed
        // TODO add your handling code here:
        cargarCursosDelDocumentoSeriado();
    }//GEN-LAST:event_mn_item_cargar_seriandoActionPerformed

    private void mn_item_cargar_jsonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mn_item_cargar_jsonActionPerformed
        // TODO add your handling code here:
        cargarCursosJSON();
    }//GEN-LAST:event_mn_item_cargar_jsonActionPerformed

    private void mn_item_cargar_xmlActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mn_item_cargar_xmlActionPerformed
        // TODO add your handling code here:
        cargarCursosXML();
    }//GEN-LAST:event_mn_item_cargar_xmlActionPerformed

    private void mn_aboutMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mn_aboutMouseClicked
        // TODO add your handling code here:
        JOptionPane.showMessageDialog(null, "David Infantes Hervas \nCarlos Zaragoza Beato",
                "Version 1.0", JOptionPane.INFORMATION_MESSAGE);
    }//GEN-LAST:event_mn_aboutMouseClicked

    /**
     * Método utilizado para guardar en un archivo los grupos filtrados
     * @param evt 
     */
    private void btn_guardar_grupos_filtradosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_guardar_grupos_filtradosActionPerformed
        // TODO add your handling code here:
        if (almacenGruposFiltrados.size() > 0) {
            String ruta = utilidades.añadirArchivoFiltrado(txf_guardar_grupos_filtradas.getText(), "grp");

            try {
                grd.GuardarGrupos(utilidades.añadirArchivoFiltrado(txf_guardar_grupos_filtradas.getText(), "grp"), almacenGruposFiltrados);
                JOptionPane.showMessageDialog(null, "Las Grupos Filtrados se guardaron en " + ruta,
                    "Info!", JOptionPane.INFORMATION_MESSAGE);
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "No se han podido guardar los datos en la siguiente ruta " + ruta,
                    "ERROR!", JOptionPane.ERROR_MESSAGE);
            }
        }
    }//GEN-LAST:event_btn_guardar_grupos_filtradosActionPerformed

    private void rb_filtrar_grupos_codigo_cursoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rb_filtrar_grupos_codigo_cursoActionPerformed
        // TODO add your handling code here:
        if (rb_filtrar_grupos_codigo_curso.isSelected()) {
            filtrarGrupos = "CodigoGrupos";
        }
    }//GEN-LAST:event_rb_filtrar_grupos_codigo_cursoActionPerformed

    private void rb_filtrar_grupos_nombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rb_filtrar_grupos_nombreActionPerformed
        // TODO add your handling code here:
        if (rb_filtrar_grupos_nombre.isSelected()) {
            filtrarGrupos = "NombreGrupos";
        }
    }//GEN-LAST:event_rb_filtrar_grupos_nombreActionPerformed

    private void rb_filtrar_grupos_claveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rb_filtrar_grupos_claveActionPerformed
        // TODO add your handling code here:
        if (rb_filtrar_grupos_clave.isSelected()) {
            filtrarGrupos = "ClaveGrupos";
        }
    }//GEN-LAST:event_rb_filtrar_grupos_claveActionPerformed

    private void txf_filtrar_grupoKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txf_filtrar_grupoKeyReleased
        // TODO add your handling code here:
        rellenarTablaGrupos(filtrar.filtrarGrupos(txf_filtrar_grupo.getText(), filtrarGrupos, almacenGrupos));
        almacenGruposFiltrados = filtrar.filtrarGrupos(txf_filtrar_grupo.getText(), filtrarGrupos, almacenGrupos);
    }//GEN-LAST:event_txf_filtrar_grupoKeyReleased

    private void rb_nombre_materiasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rb_nombre_materiasActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rb_nombre_materiasActionPerformed

    private void btn_controladorCursosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_controladorCursosActionPerformed
        dialogo_cursos.setVisible(true);
    }//GEN-LAST:event_btn_controladorCursosActionPerformed

    private void btn_controladorGruposActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_controladorGruposActionPerformed
        dialogo_grupos.setVisible(true);
    }//GEN-LAST:event_btn_controladorGruposActionPerformed

    private void btn_controladorMateriasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_controladorMateriasActionPerformed
        dialogo_materias.setVisible(true);
    }//GEN-LAST:event_btn_controladorMateriasActionPerformed

    /**
     * Método utilizado para eliminar materias.
     * @param evt 
     */
    private void btn_eliminar_materiaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_eliminar_materiaActionPerformed
        // TODO add your handling code here
        try {
            if (list_dialogo_materias_seleccionados.getSelectedIndex() != -1 && list_dialogo_cursos.getSelectedIndex() != -1) {
                eliminarMateriaDeCurso((Materias) dfl_dialogo_materias_seleccionados.get(list_dialogo_materias_seleccionados.getSelectedIndex()));
            } else {
                JOptionPane.showMessageDialog(null, "Seleccione un grupo, y un curso.",
                    "ERROR!", JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Seleccione una materia, y un curso.",
                "ERROR!", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_btn_eliminar_materiaActionPerformed

    /**
     * Método utilizado para añadir materias.
     * @param evt 
     */
    private void btn_insertar_materiaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_insertar_materiaActionPerformed
        // TODO add your handling code here:

        try {
            if (list_dialogo_materias_cursos.getSelectedIndex() != -1 && list_dialogo_cursos.getSelectedIndex() != -1) {
                añadirMateriaACurso((Materias) dfl_dialogo_materias_cursos.get(list_dialogo_materias_cursos.getSelectedIndex()));

                JOptionPane.showMessageDialog(null, "Materia Insertada.",
                    "Insertada", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(null, "Seleccione un grupo, y un curso.",
                    "ERROR!", JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Seleccione una materia, y un curso.",
                "ERROR!", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_btn_insertar_materiaActionPerformed

    /**
     * Método utilizado para eliminar grupos
     * @param evt 
     */
    private void btn_eliminar_grupoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_eliminar_grupoActionPerformed
        // TODO add your handling code here:
        try {
            if (list_dialogo_grupos_seleccionados.getSelectedIndex() != -1 && list_dialogo_cursos.getSelectedIndex() != -1) {
                eliminarGrupoDeCurso((Grupo) dfl_dialogo_grupos_seleccionados.get(list_dialogo_grupos_seleccionados.getSelectedIndex()));
            } else {
                JOptionPane.showMessageDialog(null, "Seleccione un grupo, y un curso.",
                    "ERROR!", JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Seleccione un grupo, y un curso.",
                "ERROR!", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_btn_eliminar_grupoActionPerformed

    /**
     * Método utilizado para añadir grupos
     * @param evt 
     */
    private void btn_insertar_grupoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_insertar_grupoActionPerformed
        // TODO add your handling code here:
        try {
            if (list_dialogo_grupos_cursos.getSelectedIndex() != -1 && list_dialogo_cursos.getSelectedIndex() != -1) {
                añadirGrupoACurso((Grupo) dfl_dialogo_grupos.get(list_dialogo_grupos_cursos.getSelectedIndex()));

                JOptionPane.showMessageDialog(null, "Grupo Insertado.",
                    "Insertado", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(null, "Seleccione un grupo, y un curso.",
                    "ERROR!", JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Seleccione un grupo, y un curso.",
                "ERROR!", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_btn_insertar_grupoActionPerformed

    private void txf_filtrar_dialogo_cursosKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txf_filtrar_dialogo_cursosKeyReleased
        // TODO add your handling code here:
        utilidades.rellenarListaCursos(dfl_dialogo_cursos, filtrar.filtrarCursos(txf_filtrar_dialogo_cursos.getText(), "CodigoCursos", almacenCursos));
    }//GEN-LAST:event_txf_filtrar_dialogo_cursosKeyReleased

    private void txf_dialogo_cursos_descripcionKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txf_dialogo_cursos_descripcionKeyTyped

    }//GEN-LAST:event_txf_dialogo_cursos_descripcionKeyTyped

    private void txf_dialogo_cursos_descripcionInputMethodTextChanged(java.awt.event.InputMethodEvent evt) {//GEN-FIRST:event_txf_dialogo_cursos_descripcionInputMethodTextChanged

    }//GEN-LAST:event_txf_dialogo_cursos_descripcionInputMethodTextChanged

    private void txf_dialogo_cursos_abreviaturaKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txf_dialogo_cursos_abreviaturaKeyTyped

    }//GEN-LAST:event_txf_dialogo_cursos_abreviaturaKeyTyped

    private void txf_dialogo_cursos_codigo_cursoKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txf_dialogo_cursos_codigo_cursoKeyTyped

    }//GEN-LAST:event_txf_dialogo_cursos_codigo_cursoKeyTyped

    private void txf_dialogo_cursos_codigo_cursoKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txf_dialogo_cursos_codigo_cursoKeyReleased

    }//GEN-LAST:event_txf_dialogo_cursos_codigo_cursoKeyReleased

    private void list_dialogo_cursosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_list_dialogo_cursosMouseClicked
        // TODO add your handling code here:
        rellenarParametrosCursoSeleccionado(utilidades.transformarCadenaTextoCurso(dfl_dialogo_cursos.get(list_dialogo_cursos.getSelectedIndex()).toString(), almacenCursos));
    }//GEN-LAST:event_list_dialogo_cursosMouseClicked

    private void btn_crearGrupoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_crearGrupoActionPerformed
        añadirNuevoGrupo();
    }//GEN-LAST:event_btn_crearGrupoActionPerformed

    private void btn_editarGrupoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_editarGrupoActionPerformed
        editarGrupo();
    }//GEN-LAST:event_btn_editarGrupoActionPerformed

    private void btn_eliminarGrupoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_eliminarGrupoActionPerformed
        eliminarGrupo();
    }//GEN-LAST:event_btn_eliminarGrupoActionPerformed

    private void btn_eliminarCursoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_eliminarCursoActionPerformed
        EliminarCurso();
    }//GEN-LAST:event_btn_eliminarCursoActionPerformed

    private void btn_crearCursoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_crearCursoActionPerformed
        añadirCurso();
    }//GEN-LAST:event_btn_crearCursoActionPerformed

    private void btn_editarCursoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_editarCursoActionPerformed
        EditarCurso();
    }//GEN-LAST:event_btn_editarCursoActionPerformed

    private void btn_crearMateriaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_crearMateriaActionPerformed
        añadirNuevaMateria();
    }//GEN-LAST:event_btn_crearMateriaActionPerformed

    private void btn_editarMateriaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_editarMateriaActionPerformed
        editarMaterias();
    }//GEN-LAST:event_btn_editarMateriaActionPerformed

    private void btn_eliminarMateriaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_eliminarMateriaActionPerformed
        eliminarMateria();
    }//GEN-LAST:event_btn_eliminarMateriaActionPerformed

    private void btn_guardarPropiedadesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_guardarPropiedadesMouseClicked
         accionConfiguracion();
    }//GEN-LAST:event_btn_guardarPropiedadesMouseClicked

    /**
     * Método utilizado para guardar los datos en un archivo con formato XML.
     * @param evt 
     */
    private void mn_guardarXMLActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mn_guardarXMLActionPerformed
        Cursos cursos = new Cursos();

        cursos.setList_curso(almacenCursos);

        try {
            grd.GuardarCursosXML(rutaXml_Json.concat(rutaGuardarArchivoXML), cursos);
            JOptionPane.showMessageDialog(null, "Se guardo correctamente en formato XML!!.\n El archivo creado "
                    + "se encuentra en la ruta del proyecto -> ficheros/documentos/creados.",
                    "Hey!", JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception e) {

            JOptionPane.showMessageDialog(null, "Error al guardar el archivo XML!!",
                    "Hey!", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_mn_guardarXMLActionPerformed

    /**
     * Método utilizado para guardar los datos en un archivo con formato JSON.
     * @param evt 
     */
    private void mn_guardarJSONActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mn_guardarJSONActionPerformed
        try {
            grd.GuardarCursosJson(rutaXml_Json.concat(rutaGuardarArchivoJSON), almacenCursos);
            JOptionPane.showMessageDialog(null, "Se guardo correctamente en formato JSON!!.\n El archivo creado "
                    + "se encuentra en la ruta del proyecto -> ficheros/documentos/creados.",
                    "Hey!", JOptionPane.INFORMATION_MESSAGE);
            System.out.println(rutaXml_Json.concat(rutaGuardarArchivoJSON));
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al guardar el archivo JSON!!",
                    "Hey!", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_mn_guardarJSONActionPerformed

    private void mn_resetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mn_resetActionPerformed
        reset();
    }//GEN-LAST:event_mn_resetActionPerformed

    private void mn_propiedadesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mn_propiedadesActionPerformed
        dialogo_propiedades.setVisible(true);
    }//GEN-LAST:event_mn_propiedadesActionPerformed

    /*Cargar*/
    /**
     * Carga el documentos seriado que se crear al iniciar la aplicación
     */
    private void cargarCursosDelDocumentoSeriado() {
        try {
            almacenCursosSeriando = cargar.cargarCursosSeriando(rutaCurso);
            utilidades.rellenarListaCursos(dfl_dialogo_cargar_cursos, almacenCursosSeriando);
            utilidades.cargarGruposATravesDeLista(almacenCursosSeriando, dfl_dialogo_cargar_grupos);
            utilidades.cargarMateriasATravesDeLista(almacenCursosSeriando, dfl_dialogo_cargar_materias);

            lbl_cargado_actualmente.setText("Datos cargados de un archivo SERIANDO");

            JOptionPane.showMessageDialog(null, "Se cargo correctamente el archivo en formato Seriando!!",
                    "Hey!", JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al cargar el archivo Seriado!!!!",
                    "ERROR!", JOptionPane.ERROR_MESSAGE);
        }

    }

    /**
     * Carga los cursos del xml
     */
    private void cargarCursosXML() {
        JFileChooser fileChooser = new JFileChooser("./ficheros/documentos/creados");

        int seleccion = fileChooser.showDialog(dialogo_cargar, "Aceptar");
        if (seleccion == JFileChooser.APPROVE_OPTION) {
            File f = fileChooser.getSelectedFile();
            ArrayList<Curso> list_curso = new ArrayList<Curso>();

            try {
                if (f.getPath().endsWith("xml")) {
                    list_curso = cargar.cargarCursosXMl(f.getPath()).getList_curso();

                    utilidades.rellenarListaCursos(dfl_dialogo_cargar_cursos, list_curso);
                    utilidades.cargarGruposATravesDeLista(list_curso, dfl_dialogo_cargar_grupos);
                    utilidades.cargarMateriasATravesDeLista(list_curso, dfl_dialogo_cargar_materias);

                    lbl_cargado_actualmente.setText("Datos cargados de un archivo XML");

                    JOptionPane.showMessageDialog(null, "Se cargo correctamente el archivo en formato XML!!",
                            "Hey!", JOptionPane.INFORMATION_MESSAGE);
                } else {

                    dfl_dialogo_cargar_cursos.clear();
                    dfl_dialogo_cargar_grupos.clear();
                    dfl_dialogo_cargar_materias.clear();
                    JOptionPane.showMessageDialog(null, "Seleccione un archivo XML!!",
                            "Hey!", JOptionPane.ERROR_MESSAGE);

                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Error al cargar el archivo JXML!!",
                        "Hey!", JOptionPane.ERROR_MESSAGE);

                dfl_dialogo_cargar_cursos.clear();
                dfl_dialogo_cargar_grupos.clear();
                dfl_dialogo_cargar_materias.clear();
            }
        }
    }

    /**
     * Carga los cursos en formato JSON
     */
    private void cargarCursosJSON() {
        JFileChooser fileChooser = new JFileChooser("./ficheros/documentos/creados");

        int seleccion = fileChooser.showDialog(dialogo_cargar, "Aceptar");
        if (seleccion == JFileChooser.APPROVE_OPTION) {
            File f = fileChooser.getSelectedFile();
            ArrayList<Curso> list_curso = new ArrayList<Curso>();

            list_curso = cargar.cargarCursosJSON(f.getAbsolutePath());
            try {
                utilidades.rellenarListaCursos(dfl_dialogo_cargar_cursos, list_curso);
                utilidades.cargarGruposATravesDeLista(list_curso, dfl_dialogo_cargar_grupos);
                utilidades.cargarMateriasATravesDeLista(list_curso, dfl_dialogo_cargar_materias);

                lbl_cargado_actualmente.setText("Datos cargados de un archivo JSON");

                JOptionPane.showMessageDialog(null, "Se cargo correctamente el archivo en formato JSON!!",
                        "Hey!", JOptionPane.INFORMATION_MESSAGE);

            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Error al cargar el archivo JSON!!",
                        "Hey!", JOptionPane.ERROR_MESSAGE);
                dfl_dialogo_cargar_cursos.clear();
                dfl_dialogo_cargar_grupos.clear();
                dfl_dialogo_cargar_materias.clear();
            }
        }

    }

    /*Acciones Curso*/
    /**
     * Añadir un Curso nuevo
     */
    private void añadirCurso() {
        Curso crs = null;
        ArrayList<Grupo> lista_vacia_grupos = new ArrayList<Grupo>();
        ArrayList<Materias> lista_vacia_materias = new ArrayList<Materias>();

        if (txf_dialogo_cursos_abreviatura.getText().length() != 0
                && txf_dialogo_cursos_codigo_curso.getText().length() != 0
                && txf_dialogo_cursos_descripcion.getText().length() != 0) {
            almacenCursos.add(crs = new Curso(txf_dialogo_cursos_codigo_curso.getText(), txf_dialogo_cursos_abreviatura.getText(), txf_dialogo_cursos_descripcion.getText()));

            if (!dfl_dialogo_grupos_seleccionados.isEmpty()) {
                for (int i = 0; i < dfl_dialogo_grupos_seleccionados.getSize(); i++) {
                    Grupo grp = (Grupo) dfl_dialogo_grupos_seleccionados.getElementAt(i);
                    lista_vacia_grupos.add(grp);
                }
            }

            if (!dfl_dialogo_materias_seleccionados.isEmpty()) {
                for (int i = 0; i < dfl_dialogo_materias_seleccionados.getSize(); i++) {
                    Materias mtr = (Materias) dfl_dialogo_materias_seleccionados.getElementAt(i);
                    lista_vacia_materias.add(mtr);
                }
            }

            crs.setLista_grupos(lista_vacia_grupos);
            crs.setLista_materias(lista_vacia_materias);

            utilidades.rellenarListaCursos(dfl_dialogo_cursos, almacenCursos);

            JOptionPane.showMessageDialog(null, "Se añadio correctamente el curso!!",
                    "Hey!", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, "Introduzca todos los parametros!!!",
                    "Hey!", JOptionPane.ERROR_MESSAGE);
        }

        limpiarTxfDialogoCursos();
    }

    /**
     * Añade un grupo al curso
     *
     * @param grupo
     */
    private void añadirGrupoACurso(Grupo grupo) {
        dfl_dialogo_grupos_seleccionados.clear();
        cursoSeleccionado.getLista_grupos().add(grupo);
        utilidades.rellenarListaGrupos(dfl_dialogo_grupos_seleccionados, cursoSeleccionado.getLista_grupos());
    }

    /**
     * Elimina un grupo del Curso
     *
     * @param grupo
     */
    private void eliminarGrupoDeCurso(Grupo grupo) {
        dfl_dialogo_grupos_seleccionados.clear();
        cursoSeleccionado.getLista_grupos().remove(grupo);
        utilidades.rellenarListaGrupos(dfl_dialogo_grupos_seleccionados, cursoSeleccionado.getLista_grupos());
    }

    /**
     * Añade una materia al curso
     *
     * @param mtr
     */
    private void añadirMateriaACurso(Materias mtr) {
        dfl_dialogo_materias_seleccionados.clear();
        cursoSeleccionado.getLista_materias().add(mtr);
        utilidades.rellenarListaMaterias(dfl_dialogo_materias_seleccionados, cursoSeleccionado.getLista_materias());
    }

    /**
     * Elimina una materia al curso
     *
     * @param mtr
     */
    private void eliminarMateriaDeCurso(Materias mtr) {
        dfl_dialogo_materias_seleccionados.clear();
        cursoSeleccionado.getLista_materias().remove(mtr);
        utilidades.rellenarListaMaterias(dfl_dialogo_materias_seleccionados, cursoSeleccionado.getLista_materias());
    }

    /**
     * Edita un curso
     */
    private void EditarCurso() {
        if (list_dialogo_cursos.getSelectedIndex() != -1) {
            Curso crs_selected = almacenCursos.get(list_dialogo_cursos.getSelectedIndex());

            ArrayList<Curso> listaFiltrada = new ArrayList<Curso>();

            
            if (txf_dialogo_cursos_abreviatura.getText().length() != 0
                    && txf_dialogo_cursos_codigo_curso.getText().length() != 0
                    && txf_dialogo_cursos_descripcion.getText().length() != 0) {



            Curso nuevo = new Curso(txf_dialogo_cursos_codigo_curso.getText(), txf_dialogo_cursos_abreviatura.getText(),txf_dialogo_cursos_descripcion.getText());
               
            
         for (Curso crs2 : almacenCursos) {
                if (!crs2.getCodigo_curso().equalsIgnoreCase(crs_selected.getCodigo_curso())) {
                    listaFiltrada.add(crs2);
                }
            }
            
            listaFiltrada.add(nuevo);
            almacenCursos = listaFiltrada;
  
            }

            System.out.println(almacenCursos.size());
            utilidades.rellenarListaCursos(dfl_dialogo_cursos, almacenCursos);
            utilidades.rellenarListaCursos(dflCursos, almacenCursos);

            limpiarTxfDialogoCursos();

            JOptionPane.showMessageDialog(null, "Se edito correctamente el curso!!",
                    "Hey!", JOptionPane.INFORMATION_MESSAGE);

        } else {
            JOptionPane.showMessageDialog(null, "Seleccione un curso!!",
                    "Hey!", JOptionPane.ERROR_MESSAGE);
        }

    }

    /**
     * Elimina un curso
     */
    private void EliminarCurso() {
        Curso crs1 = null;
        if (list_dialogo_cursos.getSelectedIndex() != -1) {

            ArrayList<Curso> listaFiltrada = new ArrayList<Curso>();

            crs1 = utilidades.transformarCadenaTextoCurso(dfl_dialogo_cursos.get(list_dialogo_cursos.getSelectedIndex()).toString(), almacenCursos);

            for (Curso crs : almacenCursos) {
                if (!crs.getAbreviatura_curso().equals(crs1.getAbreviatura_curso())) {
                    listaFiltrada.add(crs);
                }
            }

            almacenCursos = listaFiltrada;

            utilidades.rellenarListaCursos(dfl_dialogo_cursos, almacenCursos);
            utilidades.rellenarListaCursos(dflCursos, almacenCursos);

            limpiarTxfDialogoCursos();

            JOptionPane.showMessageDialog(null, "La eliminación se realizo con éxito!!!",
                    "Hey!", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, "Seleccione un elemento por favor!!!",
                    "Hey!", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void limpiarTxfDialogoCursos() {
        txf_dialogo_cursos_abreviatura.setText("");
        txf_dialogo_cursos_codigo_curso.setText("");
        txf_dialogo_cursos_descripcion.setText("");
    }

    /**
     * Rellena los campos del curso que se ha seleccionado.
     * @param crs 
     */
    private void rellenarParametrosCursoSeleccionado(Curso crs) {
        cursoSeleccionado = crs;

        utilidades.rellenarListaMaterias(dfl_dialogo_materias_seleccionados, cursoSeleccionado.getLista_materias());
        utilidades.rellenarListaGrupos(dfl_dialogo_grupos_seleccionados, cursoSeleccionado.getLista_grupos());
        txf_dialogo_cursos_abreviatura.setText(cursoSeleccionado.getAbreviatura_curso());
        txf_dialogo_cursos_codigo_curso.setText(cursoSeleccionado.getCodigo_curso());
        txf_dialogo_cursos_descripcion.setText(cursoSeleccionado.getDescripcion_curso());
    }

    /*Acciones Grupos*/
    /**
     * Añade un nuevo grupo
     */
    private void añadirNuevoGrupo() {
        if (txf_dialogo_grupos_clave.getText().length() > 0
                && txf_dialogo_grupos_nombre_grupo.getText().length() > 0) {

            Grupo grp = new Grupo(txf_dialogo_grupos_clave.getText(), txf_dialogo_grupos_nombre_grupo.getText());

            almacenGrupos.add(grp);

            actualizarTablasGrupos();

            limpiarTxfDialogoGrupos();

            JOptionPane.showMessageDialog(null, "Grupo Añadido con éxito!!!",
                    "Hey!", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, "Introduzca todos los elementos, por favor!!!",
                    "Hey!", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Actualiza la tabla de los grupos
     */
    private void actualizarTablasGrupos() {
        utilidades.rellenarListaGrupos(dfl_dialogo_grupos, almacenGrupos);

        for (Grupo grp : almacenGrupos) {
            utilidades.rellenarTablaGrupos(grp, datosGrupos, dftGrupos);
        }
    }

    /**
     * Rellena los campos del grupo.
     */
    private void rellenarParametrosGrupos() {
        txf_dialogo_grupos_clave.setText(grupoSeleccionado.getClave());
        txf_dialogo_grupos_nombre_grupo.setText(grupoSeleccionado.getNombre());
    }

    /**
     * Método utilizado para editar los datos de un grupo
     */
    private void editarGrupo() {
        if (list_dialogo_grupos.getSelectedIndex() != -1) {

            if (txf_dialogo_grupos_clave.getText().length() > 0
                    && txf_dialogo_grupos_nombre_grupo.getText().length() > 0) {
                grupoSeleccionado.setClave(txf_dialogo_grupos_clave.getText());
                grupoSeleccionado.setNombre(txf_dialogo_grupos_nombre_grupo.getText());

                actualizarTablasGrupos();

                limpiarTxfDialogoGrupos();
            }
            JOptionPane.showMessageDialog(null, "Se edito correctamente el Grupo!!",
                    "Hey!", JOptionPane.INFORMATION_MESSAGE);

        } else {
            JOptionPane.showMessageDialog(null, "Seleccione un Grupo!!",
                    "Hey!", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Método utilizado para eliminar un grupo
     */
    private void eliminarGrupo() {
        if (list_dialogo_grupos.getSelectedIndex() != -1) {

            almacenGrupos.remove(list_dialogo_grupos.getSelectedIndex());

            actualizarTablasGrupos();

            cursoSeleccionado = null;

            limpiarTxfDialogoGrupos();

            JOptionPane.showMessageDialog(null, "Grupo eliminado con éxito!!!",
                    "Hey!", JOptionPane.INFORMATION_MESSAGE);

        } else {
            JOptionPane.showMessageDialog(null, "Seleccione un elemento por favor!!!",
                    "Hey!", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void limpiarTxfDialogoGrupos() {
        txf_dialogo_grupos_clave.setText("");
        txf_dialogo_grupos_nombre_grupo.setText("");
    }

    /**
     * ***************
     */
    /*Acciones Materias*/
    /**
     * Añade una nueva materia
     */
    private void añadirNuevaMateria() {
        if (txf_dialogo_materias_nombre.getText().length() > 0
                && txf_dialogo_materias_iso.getText().length() > 0
                && txf_dialogo_materias_clave.getText().length() > 0
                && txf_dialogo_materias_codigo_curso.getText().length() > 0
                && txf_dialogo_materias_descripcion.getText().length() > 0
                && txf_dialogo_materias_abreviatura.getText().length() > 0
                && txf_dialogo_materias_departamento.getText().length() > 0) {

            Materias mtr = new Materias(txf_dialogo_materias_nombre.getText(),
                    txf_dialogo_materias_clave.getText(),
                    txf_dialogo_materias_iso.getText(),
                    txf_dialogo_materias_codigo_curso.getText(),
                    txf_dialogo_materias_descripcion.getText(),
                    txf_dialogo_materias_abreviatura.getText(),
                    txf_dialogo_materias_departamento.getText());

            almacenMaterias.add(mtr);

            actualizarInformacionMaterias();

            JOptionPane.showMessageDialog(null, "Materia insertada con éxito!!!",
                    "Hey!", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, "Introduzca todos los elementos, por favor!!!",
                    "Hey!", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Actualiza la lista de materias.
     */
    private void actualizarInformacionMaterias() {
        utilidades.rellenarListaMaterias(dfl_dialogo_materias_cursos, almacenMaterias);
        utilidades.rellenarListaMaterias(dfl_dialogo_materias, almacenMaterias);
        rellenarTablaMaterias(almacenMaterias);
    }

    /**
     * Método utilizado para editar las materias.
     */
    private void editarMaterias() {
        if (list_dialogo_materias.getSelectedIndex() != -1) {
            if (txf_dialogo_materias_nombre.getText().length() > 0
                    && txf_dialogo_materias_iso.getText().length() > 0
                    && txf_dialogo_materias_clave.getText().length() > 0
                    && txf_dialogo_materias_codigo_curso.getText().length() > 0
                    && txf_dialogo_materias_descripcion.getText().length() > 0
                    && txf_dialogo_materias_abreviatura.getText().length() > 0
                    && txf_dialogo_materias_departamento.getText().length() > 0) {

                materiaSeleccionada.setNombre(txf_dialogo_materias_nombre.getText());
                materiaSeleccionada.setIso(txf_dialogo_materias_iso.getText());
                materiaSeleccionada.setClave(txf_dialogo_materias_clave.getText());
                materiaSeleccionada.setCodigo_curso(txf_dialogo_materias_codigo_curso.getText());
                materiaSeleccionada.setDescripcion_curso(txf_dialogo_materias_descripcion.getText());
                materiaSeleccionada.setAbreviatura_curso(txf_dialogo_materias_abreviatura.getText());
                materiaSeleccionada.setDepartamento(txf_dialogo_materias_departamento.getText());

                actualizarInformacionMaterias();

                JOptionPane.showMessageDialog(null, "Materia Eliminada con exito!!!",
                        "Hey!", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(null, "Introduzca todos los parametros de las materias!!!",
                        "Hey!", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(null, "Seleccione una Materia por favor!!!",
                    "Hey!", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Método utilizado para eliminar materias.
     */
    private void eliminarMateria() {
        if (list_dialogo_materias.getSelectedIndex() != -1) {

            almacenMaterias.remove(list_dialogo_materias.getSelectedIndex());

            actualizarInformacionMaterias();

            cursoSeleccionado = null;

            JOptionPane.showMessageDialog(null, "Materia Eliminada con exito!!!",
                    "Hey!", JOptionPane.INFORMATION_MESSAGE);

        } else {
            JOptionPane.showMessageDialog(null, "Seleccione un elemento por favor!!!",
                    "Hey!", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Método utilizado para rellenar los campos de las amterias.
     * @param mtr 
     */
    private void rellenarParametrosMaterias(Materias mtr) {

        materiaSeleccionada = mtr;

        txf_dialogo_materias_nombre.setText(materiaSeleccionada.getNombre());
        txf_dialogo_materias_iso.setText(materiaSeleccionada.getIso());
        txf_dialogo_materias_clave.setText(materiaSeleccionada.getClave());
        txf_dialogo_materias_codigo_curso.setText(materiaSeleccionada.getCodigo_curso());
        txf_dialogo_materias_abreviatura.setText(materiaSeleccionada.getAbreviatura_curso());
        txf_dialogo_materias_departamento.setText(materiaSeleccionada.getDepartamento());
        txf_dialogo_materias_descripcion.setText(materiaSeleccionada.getDescripcion_curso());

    }

    /**
     * ***************
     */
    /**
     * Método para volver a cargar la información del archivo XML original.
     */
    private void reset() {
        utilidades.limpiarTablaFicheros(dftGrupos);
        utilidades.limpiarTablaFicheros(dftMaterias);

        almacenCursos.clear();
        almacenMaterias.clear();
        almacenGrupos.clear();

        recuperarMaterias();
        recuperarGrupos();
        recuperarCursos();

        rellenarTablas_Vistas();
    }

    /*Acciones Archivo Configuracion*/
    /**
     * Carga la configuración del archivo de configuración del proyecto.
     */
    private void cargarArchivoPropiedades() {
        try {
            configuracion.load(new FileInputStream("ficheros/configuracion/configuracion.props"));

            usuario = configuracion.getProperty("user");
            rutaGuardarArchivoXML = configuracion.getProperty("nombre_archivo_xml");
            rutaGuardarArchivoJSON = configuracion.getProperty("nombre_archivo_json");
            tema = configuracion.getProperty("tema");

            txf_dialogo_propiedad_usuario.setText(usuario);
            txf_dialogo_propiedades_nombre_fichero_xml.setText(rutaGuardarArchivoXML);
            txf_dialogo_propiedades_nombre_fichero_json.setText(rutaGuardarArchivoJSON);
            if (tema.equals("false")) {
                rb_tema_oscuro.setSelected(true);
            } else {
                rb_tema_claro.setSelected(true);
            }
            cambiarTema(tema);

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    /**
     * Cambia la paleta de colores de la interfaz 
     * @param condition 
     */
    private void cambiarTema(String condition) {
        if (condition.equals("false")) {
            principal.setBackground(Color.lightGray);
            pn_cursos.setBackground(Color.lightGray);
            pn_grupos.setBackground(Color.lightGray);
            pn_materias.setBackground(Color.lightGray);
            pn_filtrar_cursos.setBackground(Color.lightGray);
            pn_filtrar_grupos.setBackground(Color.lightGray);
            pn_filtrar_materias.setBackground(Color.lightGray);
            panel.setBackground(Color.lightGray);
        } else {
            principal.setBackground(Color.white);
            pn_cursos.setBackground(Color.white);
            pn_grupos.setBackground(Color.white);
            pn_materias.setBackground(Color.white);
            pn_filtrar_cursos.setBackground(Color.white);
            pn_filtrar_grupos.setBackground(Color.white);
            pn_filtrar_materias.setBackground(Color.white);
            panel.setBackground(Color.white);
        }

    }

    /**
     * Permite editar la información del archivo de configuración del proyecto
     */
    private void escribirArchivoPropiedades() {

        configuracion.setProperty("user", txf_dialogo_propiedad_usuario.getText());
        configuracion.setProperty("nombre_archivo_xml", txf_dialogo_propiedades_nombre_fichero_xml.getText());
        configuracion.setProperty("nombre_archivo_json", txf_dialogo_propiedades_nombre_fichero_json.getText());
        configuracion.setProperty("tema", rb_tema_claro.isSelected() + "");

        usuario = txf_dialogo_propiedad_usuario.getText();
        rutaGuardarArchivoXML = txf_dialogo_propiedades_nombre_fichero_xml.getText();
        rutaGuardarArchivoJSON = txf_dialogo_propiedades_nombre_fichero_json.getText();
        tema = rb_tema_claro.isSelected() + "";
        try {
            configuracion.store(new FileOutputStream("ficheros/configuracion/configuracion.props"),
                    "Fichero de configuracion");
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
    }

    /**
     * Confirmación de los cambios del archivo de configuración del proyecto
     */
    private void accionConfiguracion() {

        if (txf_dialogo_propiedad_usuario.getText().length() > 0
                && txf_dialogo_propiedades_nombre_fichero_xml.getText().length() > 0
                && txf_dialogo_propiedades_nombre_fichero_json.getText().length() > 0) {

            int valor = (JOptionPane.showConfirmDialog(null, "¿Desea sobescribir los datos?", "Cuidado", JOptionPane.YES_NO_OPTION));

            if (valor == JOptionPane.YES_OPTION) {
                escribirArchivoPropiedades();
                cambiarTema(tema);
                this.setTitle("Nombre Usuario: ".concat(usuario));
            }

        }
    }

    /**
     * *******
     */
    /**
     * *****************************
     */
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(interfaz.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(interfaz.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(interfaz.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(interfaz.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new interfaz().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup bg_filtrar_curso;
    private javax.swing.ButtonGroup bg_filtrar_grupos;
    private javax.swing.ButtonGroup bg_filtrar_materias;
    private javax.swing.JButton btn_controladorCursos;
    private javax.swing.JButton btn_controladorGrupos;
    private javax.swing.JButton btn_controladorMaterias;
    private javax.swing.JButton btn_crearCurso;
    private javax.swing.JButton btn_crearGrupo;
    private javax.swing.JButton btn_crearMateria;
    private javax.swing.JButton btn_editarCurso;
    private javax.swing.JButton btn_editarGrupo;
    private javax.swing.JButton btn_editarMateria;
    private javax.swing.JButton btn_eliminarCurso;
    private javax.swing.JButton btn_eliminarGrupo;
    private javax.swing.JButton btn_eliminarMateria;
    private javax.swing.JButton btn_eliminar_grupo;
    private javax.swing.JButton btn_eliminar_materia;
    private javax.swing.JButton btn_guardarPropiedades;
    private javax.swing.JButton btn_guardar_cursos_filtrados;
    private javax.swing.JButton btn_guardar_grupos_filtrados;
    private javax.swing.JButton btn_guardar_materias_filtradas;
    private javax.swing.JButton btn_insertar_grupo;
    private javax.swing.JButton btn_insertar_materia;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JDialog dialogo_cargar;
    private javax.swing.JDialog dialogo_cursos;
    private javax.swing.JDialog dialogo_grupos;
    private javax.swing.JDialog dialogo_materias;
    private javax.swing.JDialog dialogo_propiedades;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenuBar jMenuBar2;
    private javax.swing.JMenuBar jMenuBar6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JRadioButton jRadioButton1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane10;
    private javax.swing.JScrollPane jScrollPane11;
    private javax.swing.JScrollPane jScrollPane12;
    private javax.swing.JScrollPane jScrollPane13;
    private javax.swing.JScrollPane jScrollPane14;
    private javax.swing.JScrollPane jScrollPane15;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JScrollPane jScrollPane9;
    private javax.swing.JTable jTable1;
    private javax.swing.JLabel lbl_cargado_actualmente;
    private javax.swing.JList<String> list_cargar_cursos;
    private javax.swing.JList<String> list_cargar_grupos;
    private javax.swing.JList<String> list_cargar_materias;
    private javax.swing.JList<String> list_cursos;
    private javax.swing.JList<String> list_dialogo_cursos;
    private javax.swing.JList<String> list_dialogo_grupos;
    private javax.swing.JList<String> list_dialogo_grupos_cursos;
    private javax.swing.JList<String> list_dialogo_grupos_seleccionados;
    private javax.swing.JList<String> list_dialogo_materias;
    private javax.swing.JList<String> list_dialogo_materias_cursos;
    private javax.swing.JList<String> list_dialogo_materias_seleccionados;
    private javax.swing.JMenu mn_about;
    private javax.swing.JMenu mn_archivo;
    private javax.swing.JMenu mn_cargar;
    private javax.swing.JMenu mn_configuracion;
    private javax.swing.JMenu mn_guardar;
    private javax.swing.JMenuItem mn_guardarJSON;
    private javax.swing.JMenuItem mn_guardarXML;
    private javax.swing.JMenuItem mn_item_cargar_json;
    private javax.swing.JMenuItem mn_item_cargar_seriando;
    private javax.swing.JMenuItem mn_item_cargar_xml;
    private javax.swing.JMenuItem mn_propiedades;
    private javax.swing.JMenuItem mn_reset;
    private javax.swing.JPanel panel;
    private javax.swing.JPanel pn_cursos;
    private javax.swing.JPanel pn_filtrar_cursos;
    private javax.swing.JPanel pn_filtrar_grupos;
    private javax.swing.JPanel pn_filtrar_materias;
    private javax.swing.JPanel pn_grupos;
    private javax.swing.JPanel pn_materias;
    private javax.swing.JPanel pnl_cursos;
    private javax.swing.JPanel pnl_editarCursos;
    private javax.swing.JPanel pnl_editarCursos2;
    private javax.swing.JPanel pnl_principal;
    private javax.swing.JPanel principal;
    private javax.swing.JRadioButton rb_departamento_materias;
    private javax.swing.JRadioButton rb_filtrar_abreviatura_curso;
    private javax.swing.JRadioButton rb_filtrar_codigo_curso;
    private javax.swing.JRadioButton rb_filtrar_descripcion_curso;
    private javax.swing.JRadioButton rb_filtrar_grupos_clave;
    private javax.swing.JRadioButton rb_filtrar_grupos_codigo_curso;
    private javax.swing.JRadioButton rb_filtrar_grupos_nombre;
    private javax.swing.JRadioButton rb_grupo_materias;
    private javax.swing.JRadioButton rb_iso_materias;
    private javax.swing.JRadioButton rb_nombre_materias;
    private javax.swing.JRadioButton rb_tema_claro;
    private javax.swing.JRadioButton rb_tema_oscuro;
    private javax.swing.ButtonGroup rb_theme;
    private javax.swing.JTable tbl_grupos;
    private javax.swing.JTable tbl_materias;
    private javax.swing.JTextField txf_dialogo_cursos_abreviatura;
    private javax.swing.JTextField txf_dialogo_cursos_codigo_curso;
    private javax.swing.JTextField txf_dialogo_cursos_descripcion;
    private javax.swing.JTextField txf_dialogo_grupos_clave;
    private javax.swing.JTextField txf_dialogo_grupos_filtrar;
    private javax.swing.JTextField txf_dialogo_grupos_nombre_grupo;
    private javax.swing.JTextField txf_dialogo_materias_abreviatura;
    private javax.swing.JTextField txf_dialogo_materias_clave;
    private javax.swing.JTextField txf_dialogo_materias_codigo_curso;
    private javax.swing.JTextField txf_dialogo_materias_departamento;
    private javax.swing.JTextField txf_dialogo_materias_descripcion;
    private javax.swing.JTextField txf_dialogo_materias_filtrar;
    private javax.swing.JTextField txf_dialogo_materias_iso;
    private javax.swing.JTextField txf_dialogo_materias_nombre;
    private javax.swing.JTextField txf_dialogo_propiedad_usuario;
    private javax.swing.JTextField txf_dialogo_propiedades_nombre_fichero_json;
    private javax.swing.JTextField txf_dialogo_propiedades_nombre_fichero_xml;
    private javax.swing.JTextField txf_filtrar_curso;
    private javax.swing.JTextField txf_filtrar_dialogo_cursos;
    private javax.swing.JTextField txf_filtrar_grupo;
    private javax.swing.JTextField txf_filtrar_materias;
    private javax.swing.JTextField txf_guardar_cursos_filtrados;
    private javax.swing.JTextField txf_guardar_grupos_filtradas;
    private javax.swing.JTextField txf_guardar_materias_filtradas;
    // End of variables declaration//GEN-END:variables
}
