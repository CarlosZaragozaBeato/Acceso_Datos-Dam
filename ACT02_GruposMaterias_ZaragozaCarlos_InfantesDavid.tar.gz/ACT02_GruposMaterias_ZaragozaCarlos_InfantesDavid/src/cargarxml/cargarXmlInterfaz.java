/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package cargarxml;

import java.util.ArrayList;
import model.Curso;
import model.Grupo;
import model.Materias;
import org.w3c.dom.Element;

/**
 *
 * @author carlo
 */
public interface cargarXmlInterfaz {
    
      public ArrayList<Materias> recuperarMaterias(String ruta);
      
      public Materias obtenerMaterias(Element l);
    
      public ArrayList<Grupo> recuperarGrupos(String ruta);
      
      public Grupo obtenerGrupos(Element l);
      
      public ArrayList<Curso> recuperarCursos(ArrayList<Materias> list_materias);
      
      public ArrayList<Materias> cargarMateriasDeLosCursos(String codigo_curso, ArrayList<Materias> list_materias);

      public ArrayList<Grupo> cargarGruposDeLosCursos(String codigo_curso, ArrayList<Grupo> list_grupos);
}
