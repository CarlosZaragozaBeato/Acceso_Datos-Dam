/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cargarxml;

import java.util.ArrayList;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import model.Curso;
import model.Grupo;
import model.Materias;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

/**
 *
 * @author carlo
 */
public class cargarXML implements cargarXmlInterfaz{
    /**
     * @param ruta
     * @return 
     * Método utilizado para la obtencion de las materias
     */
    @Override
    public ArrayList<Materias> recuperarMaterias(String ruta) {
      ArrayList<Materias> almacenMaterias = new ArrayList<Materias>();

        Element raiz = null;


        try {

            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

            DocumentBuilder db = dbf.newDocumentBuilder();

            Document doc = db.parse(ruta);

            raiz = doc.getDocumentElement();

            NodeList nlGrupo = doc.getElementsByTagName("listasal");

            Element elementoCiudadano;

            String[] trozos = null;
            String atributo = null;

            for (int i = 0; i < nlGrupo.getLength(); i++) {

                atributo = nlGrupo.item(i).getAttributes().item(0).getTextContent();

                if (atributo.contains("MATERIAS_")) {
                    trozos = atributo.split("MATERIAS_");

                    elementoCiudadano = (Element) nlGrupo.item(i);

                    almacenMaterias.add(obtenerMaterias(elementoCiudadano));

                }
            }

        } catch (Exception e) {
            System.out.println(e);
        }
        return almacenMaterias;
    }

    /**
     * 
     * @param l
     * @return
     * Método utilizado para crear el objeto Materia desde el archivo XML.
     */
    @Override
    public Materias obtenerMaterias(Element l) {

    String nombre, 
                clave, 
                Iso, 
                codigo_curso,
                descripcion_curso,
                abreviatura_curso
                ,departamento;

        Element el = null;
        NodeList lista = null;

        Materias mtr = null;

        lista = l.getElementsByTagName("salida");
        el = (Element) lista.item(0);
        nombre = el.getTextContent();

        lista = l.getElementsByTagName("salida");
        el = (Element) lista.item(1);
        clave = el.getTextContent();

        lista = l.getElementsByTagName("salida");
        el = (Element) lista.item(2);
        Iso = el.getTextContent();

        lista = l.getElementsByTagName("salida");
        el = (Element) lista.item(3);
        codigo_curso = el.getTextContent();

        lista = l.getElementsByTagName("salida");
        el = (Element) lista.item(4);
        descripcion_curso = el.getTextContent();

        lista = l.getElementsByTagName("salida");
        el = (Element) lista.item(5);
        abreviatura_curso = el.getTextContent();

        lista = l.getElementsByTagName("salida");
        el = (Element) lista.item(6);
        departamento = el.getTextContent();

        mtr = new Materias(nombre, clave, Iso, codigo_curso, descripcion_curso, abreviatura_curso, departamento);

        return mtr;
    }

    
    
    /**
     * @param ruta
     * @return 
     * Método utilizado para la obtencion de los Grupos
     */
    @Override
    public ArrayList<Grupo> recuperarGrupos(String ruta) {
         ArrayList<Grupo> almacenGrupos = new ArrayList<Grupo>();

        Element raiz = null;

        try {

            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

            DocumentBuilder db = dbf.newDocumentBuilder();

            Document doc = db.parse(ruta);

            raiz = doc.getDocumentElement();

            NodeList nlGrupo = doc.getElementsByTagName("listasal");

            Element elementoGrupo;

            String[] trozos = null;
            String atributo = null;

            for (int i = 0; i < nlGrupo.getLength(); i++) {

                atributo = nlGrupo.item(i).getAttributes().item(0).getTextContent();

                if (atributo.contains("GRUPOS_")) {
                    
                    trozos = atributo.split("GRUPOS_");

                    elementoGrupo = (Element) nlGrupo.item(i);

                    almacenGrupos.add(obtenerGrupos(elementoGrupo));

                }
            }

        } catch (Exception e) {System.out.println(e);}
        
        return almacenGrupos;
    }
    /**
     * 
     * @param l
     * @return
     * Método utilizado para crear el objeto Grupo desde el archivo XML.
     */
    @Override
    public Grupo obtenerGrupos(Element l) {

        String nombre, clave, curso;

        Element el = null;
        NodeList lista = null;
        Grupo grp = null;

        
        lista = l.getElementsByTagName("salida");
        el = (Element) lista.item(0);
        clave = el.getTextContent();
  
        lista = l.getElementsByTagName("salida");
        el = (Element) lista.item(1);
        nombre = el.getTextContent();

        
        lista = l.getElementsByTagName("salida");
        el = (Element) lista.item(2);
        curso = el.getTextContent();

        grp = new Grupo(clave, nombre, curso);

        return grp;
    }
    
    /**
     * @param list_materias
     * @return 
     * Método utilizado para la obtencion de los cursos
     */
    @Override
    public ArrayList<Curso> recuperarCursos(ArrayList<Materias> list_materias) {
         ArrayList<Curso> almacenCursos = new ArrayList<Curso>();
         
         for(Materias mtr: list_materias){          
             almacenCursos.add(new Curso(mtr.getCodigo_curso(), mtr.getAbreviatura_curso(), mtr.getDescripcion_curso()));      
         }
             
        return almacenCursos;
    } 
    
    /**
     * @param codigo_curso
     * @param list_materias
     * @return 
     * Recupera todas las materias que tiene un curso
     */
    @Override
    public ArrayList<Materias> cargarMateriasDeLosCursos(String codigo_curso, ArrayList<Materias> list_materias) {
     
        ArrayList<Materias> listaM = new ArrayList();
        
        for(Materias mtr: list_materias){
            if(mtr.getCodigo_curso().equals(codigo_curso)){
                listaM.add(mtr);
            }
        }
        
        return listaM;
    }
    
    /**
     * @param codigo_curso
     * @param list_grupos
     * @return 
     * Recupera todos los grupos que tiene un curso
     */
    @Override
    public ArrayList<Grupo> cargarGruposDeLosCursos(String codigo_curso, ArrayList<Grupo> list_grupos) {
       ArrayList<Grupo> listG = new ArrayList();
       
       for(Grupo grp: list_grupos){
           if(grp.getCodigo_curso().equals(codigo_curso)){
               listG.add(grp);
           }
       }
       return listG;
    } 
}
