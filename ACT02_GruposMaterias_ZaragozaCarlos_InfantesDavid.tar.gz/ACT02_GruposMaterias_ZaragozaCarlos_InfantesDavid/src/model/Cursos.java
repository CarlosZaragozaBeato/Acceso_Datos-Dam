package model;

import java.util.ArrayList;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="Cursos")
public class Cursos {
    
    ArrayList<Curso> list_curso = new ArrayList<Curso>();


    @XmlElementWrapper(name = "list_cursos") // 
    @XmlElement(name = "curso")
    public ArrayList<Curso> getList_curso() {
        return list_curso;
    }

    
    public void setList_curso(ArrayList<Curso> list_curso) {
        this.list_curso = list_curso;
    }
        public Cursos() {
    }
    
}