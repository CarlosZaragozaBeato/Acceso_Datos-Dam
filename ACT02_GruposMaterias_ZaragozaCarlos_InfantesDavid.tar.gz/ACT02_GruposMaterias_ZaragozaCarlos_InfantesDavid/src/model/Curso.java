/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.io.Serializable;
import java.util.ArrayList;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlType;

/**
 *
 * @author carlo
 */
@XmlType(propOrder = {"codigo_curso", "abreviatura_curso", "descripcion_curso","lista_grupos","lista_materias"})
public class Curso implements Serializable{
    private String codigo_curso;
    private String abreviatura_curso;
    private String descripcion_curso;
    private ArrayList<Grupo> lista_grupos = new ArrayList<Grupo>();
    private ArrayList<Materias> lista_materias = new ArrayList<Materias>();

    public Curso(String codigo_curso, String abreviatura_curso, String descripcion_curso) {
        this.codigo_curso = codigo_curso;
        this.abreviatura_curso = abreviatura_curso;
        this.descripcion_curso = descripcion_curso;
    }

    public Curso() {
    }

    
    public String getCodigo_curso() {
        return codigo_curso;
    }

    public void setCodigo_curso(String codigo_curso) {
        this.codigo_curso = codigo_curso;
    }

    public String getAbreviatura_curso() {
        return abreviatura_curso;
    }

    public void setAbreviatura_curso(String abreviatura_curso) {
        this.abreviatura_curso = abreviatura_curso;
    }

    public String getDescripcion_curso() {
        return descripcion_curso;
    }

    public void setDescripcion_curso(String descripcion_curso) {
        this.descripcion_curso = descripcion_curso;
    }


    @XmlElementWrapper(name = "listaGrupos")
    @XmlElement(name = "grupo")
    public ArrayList<Grupo> getLista_grupos() {
        return lista_grupos;
    }

    public void setLista_grupos(ArrayList<Grupo> lista_grupos) {
        this.lista_grupos = lista_grupos;
    }

    @XmlElementWrapper(name = "listaMaterias") 
    @XmlElement(name = "materia")
    public ArrayList<Materias> getLista_materias() {
        return lista_materias;
    }

    public void setLista_materias(ArrayList<Materias> lista_materias) {
        this.lista_materias = lista_materias;
    }
    
    @Override
    public String toString() {
        return "Código Curso:"+ codigo_curso + ", Descripción: "+ descripcion_curso;
    }
}
