/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlType;

/**
 *
 * @author carlo
 */
@XmlType(propOrder = {"clave", "nombre", "codigo_curso"})
public class Grupo implements Serializable{
    private String clave;
    private String nombre;
    private String codigo_curso;

    public Grupo() {
    }


    public Grupo(String clave, String nombre, String codigo_curso) {
        this.clave = clave;
        this.nombre = nombre;
        this.codigo_curso = codigo_curso;
    }

    public Grupo(String clave, String nombre) {
        this.clave = clave;
        this.nombre = nombre;
    }

    
    
    public String getClave() {
        return clave;
    }

    public void setClave(String clave) {
        this.clave = clave;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCodigo_curso() {
        return codigo_curso;
    }

    public void setCodigo_curso(String codigo_curso) {
        this.codigo_curso = codigo_curso;
    }
    
    @Override
    public String toString() {
        return nombre;
    }
}
