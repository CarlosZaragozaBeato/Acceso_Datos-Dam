/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlType;

/**
 *
 * @author carlo
 */
@XmlType(propOrder = {"nombre", "clave", "iso","codigo_curso","descripcion_curso","abreviatura_curso","departamento"})
public class Materias implements Serializable{
    private String nombre;
    private String clave;
    private String iso;
    private String codigo_curso;
    private String descripcion_curso;
    private String abreviatura_curso;
    private String departamento;

    public Materias() {
    }

    public Materias(String nombre, String clave, String Iso, String codigo_curso, String descripcion_curso, String abreviatura_curso, String departamento) {
        this.nombre = nombre;
        this.clave = clave;
        this.iso = Iso;
        this.codigo_curso = codigo_curso;
        this.descripcion_curso = descripcion_curso;
        this.abreviatura_curso = abreviatura_curso;
        this.departamento = departamento;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getClave() {
        return clave;
    }

    public void setClave(String clave) {
        this.clave = clave;
    }

    public String getIso() {
        return iso;
    }

    public void setIso(String Iso) {
        this.iso = Iso;
    }

    public String getCodigo_curso() {
        return codigo_curso;
    }

    public void setCodigo_curso(String codigo_curso) {
        this.codigo_curso = codigo_curso;
    }

    public String getDescripcion_curso() {
        return descripcion_curso;
    }

    public void setDescripcion_curso(String descripcion_curso) {
        this.descripcion_curso = descripcion_curso;
    }

    public String getAbreviatura_curso() {
        return abreviatura_curso;
    }

    public void setAbreviatura_curso(String abreviatura_curso) {
        this.abreviatura_curso = abreviatura_curso;
    }

    public String getDepartamento() {
        return departamento;
    }

    public void setDepartamento(String departamento) {
        this.departamento = departamento;
    }
    
    @Override
    public String toString() {
        return clave +"  "+nombre;
    }
  
}
