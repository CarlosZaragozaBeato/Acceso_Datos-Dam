/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package guardar;

import java.util.ArrayList;
import model.Curso;
import model.Cursos;
import model.Grupo;
import model.Materias;

/**
 *
 * @author carlo
 */
public interface guardarInterfaz {

    public void GuardarGrupos(String ruta, ArrayList<Grupo> list_grp);

    public void GuardarMaterias(String ruta, ArrayList<Materias> list_mtr);

    public void GuardarCursos(String ruta, ArrayList<Curso> list_curso);
    
    public void GuardarCursosXML(String ruta, Cursos cursos) ;
    
    public void GuardarCursosJson(String ruta, ArrayList<Curso> list_curso);
}
