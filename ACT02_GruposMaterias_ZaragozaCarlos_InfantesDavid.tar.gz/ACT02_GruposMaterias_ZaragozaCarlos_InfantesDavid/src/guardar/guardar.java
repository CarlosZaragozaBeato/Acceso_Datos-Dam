/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package guardar;

import com.google.gson.Gson;
import com.sun.xml.bind.api.JAXBRIContext;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.PropertyException;
import model.Curso;
import model.Cursos;
import model.Grupo;
import model.Materias;

/**
 *
 * @author carlo
 */
public class guardar implements guardarInterfaz {

    /**
     * 
     * @param ruta Ruta donde se crea el archivo
     * @param list_grp Lista de grupos a guardar
     * Método utilizado para guardar grupos.
     */
    @Override
    public void GuardarGrupos(String ruta, ArrayList<Grupo> list_grp) {
        try {

            File fichero = new File(ruta);
            FileOutputStream fos = new FileOutputStream(fichero);
            ObjectOutputStream oos = new ObjectOutputStream(fos);

            oos.writeObject(list_grp);

        } catch (FileNotFoundException ex) {
            System.out.println(ex.getMessage());
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }

    }

    /**
     * 
     * @param ruta Ruta donde se crea el archivo
     * @param list_mtr Lista de materias a guardar
     * Método utilizado para guardar materias.
     */
    @Override
    public void GuardarMaterias(String ruta, ArrayList<Materias> list_mtr) {
        try {
            // TODO add your handling code here:

            File fichero = new File(ruta);
            FileOutputStream fos = new FileOutputStream(fichero);
            ObjectOutputStream oos = new ObjectOutputStream(fos);

            oos.writeObject(list_mtr);

        } catch (FileNotFoundException ex) {
            System.out.println(ex.getMessage());
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }

    /**
     * 
     * @param ruta Ruta donde se crea el archivo
     * @param list_curso Lista de cursos a guardar
     * Método utilizado para guardar cursos.
     */
    @Override
    public void GuardarCursos(String ruta, ArrayList<Curso> list_curso) {

        try {
            // TODO add your handling code here:

            File fichero = new File(ruta);
            FileOutputStream fos = new FileOutputStream(fichero);
            ObjectOutputStream oos = new ObjectOutputStream(fos);

            oos.writeObject(list_curso);

        } catch (FileNotFoundException ex) {
            System.out.println(ex.getMessage());
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }

    /**
     * 
     * @param ruta Ruta donde se crea el archivo.
     * @param cursos Cursos a guardar
     * Guarda los cursos en un archivo con formato XML
     */
    @Override
    public void GuardarCursosXML(String ruta, Cursos cursos) {
        try {

            JAXBContext context = JAXBRIContext.newInstance(Cursos.class);
            Marshaller m = context.createMarshaller();
            m.setProperty(Marshaller.JAXB_ENCODING, "UTF-8");

            m.marshal(cursos, new File(ruta));

            m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
        } catch (PropertyException ex) {
            System.out.println(ex.getMessage());
        } catch (JAXBException ex) {
            System.out.println(ex.getMessage());
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

    }

    /**
     * 
     * @param ruta Ruta donde se crea el archivo.
     * @param list_curso Cursos a guardar
     * Guarda los cursos en un archivo con formato JSON
     */
    @Override
    public void GuardarCursosJson(String ruta, ArrayList<Curso> list_curso) {

        Gson gson = new Gson();

        BufferedReader bf2 = null;
        PrintWriter pw = null;

        String jRson = gson.toJson(list_curso);

        try {
            pw = new PrintWriter(new File(ruta));
            pw.print(jRson);

        } catch (FileNotFoundException ex) {
            System.out.println(ex.getMessage());
        } finally {
            pw.close();
        }
    }

}
