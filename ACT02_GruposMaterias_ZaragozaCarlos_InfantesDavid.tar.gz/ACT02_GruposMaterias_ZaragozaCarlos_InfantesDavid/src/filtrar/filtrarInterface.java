/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package filtrar;

import java.util.ArrayList;
import model.Curso;
import model.Grupo;
import model.Materias;

/**
 *
 * @author carlo
 */
public interface filtrarInterface {
    
    public ArrayList<Curso> filtrarCursos(String valor, String filtro, ArrayList<Curso>listaSinFiltrar);

    public ArrayList<Grupo> filtrarGrupos(String valor, String filtro, ArrayList<Grupo> listaSinFiltrar);
    
    public ArrayList<Materias> filtrarMaterias(String valor ,String  filtro,ArrayList<Materias> listaSinFiltra);
      
}
