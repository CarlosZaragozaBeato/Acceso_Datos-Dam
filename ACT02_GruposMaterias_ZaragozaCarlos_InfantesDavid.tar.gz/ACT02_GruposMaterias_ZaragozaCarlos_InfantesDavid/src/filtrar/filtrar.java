/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package filtrar;

import java.util.ArrayList;
import model.Curso;
import model.Grupo;
import model.Materias;

/**
 *
 * @author carlo
 */
public class filtrar implements filtrarInterface {

    /**
     * @param valor Conjunto de valores por los que se filtra.
     * @param filtro Opción elegida para filtrar
     * @param listaSinFiltrar Lista de todos los cursos
     * @return Devuelve una lista filtrada
     * Método utilizado para filtrar los cursos.
     */
    @Override
    public ArrayList<Curso> filtrarCursos(String valor, String filtro, ArrayList<Curso> listaSinFiltrar) {
        ArrayList<Curso> lista_filtrada = new ArrayList<Curso>();

        for (Curso crs : listaSinFiltrar) {
            switch (filtro) {
                case "CodigoCursos":
                    if (crs.getCodigo_curso().toLowerCase().contains(valor.toLowerCase())) {lista_filtrada.add(crs); }
                    break;
                case "AbreviaturaCursos":
                     if (crs.getAbreviatura_curso().toLowerCase().contains(valor.toLowerCase())) {lista_filtrada.add(crs); }
                    break;
                case "DescripcionCursos":
                     if (crs.getDescripcion_curso().toLowerCase().contains(valor.toLowerCase())) {lista_filtrada.add(crs); }
                    break;
            }
        }
        return lista_filtrada;
    }

    /**
     * @param valor Conjunto de valores por los que se filtra.
     * @param filtro Opción elegida para filtrar
     * @param listaSinFiltrar Lista de todos los grupos
     * @return Devuelve una lista filtrada
     * Método utilizado para filtrar los grupos.
     */
    @Override
    public ArrayList<Grupo> filtrarGrupos(String valor, String filtro, ArrayList<Grupo> listaSinFiltrar) {
        ArrayList<Grupo> lista_filtrada = new ArrayList<Grupo>();

        for (Grupo grp : listaSinFiltrar) {
            switch (filtro) {
                case "CodigoGrupos":
                    if (grp.getCodigo_curso().toLowerCase().contains(valor.toLowerCase())) {lista_filtrada.add(grp); }
                    break;
                case "NombreGrupos":
                     if (grp.getNombre().toLowerCase().contains(valor.toLowerCase())) {lista_filtrada.add(grp); }
                    break;
                case "ClaveGrupos":
                     if (grp.getClave().toLowerCase().contains(valor.toLowerCase())) {lista_filtrada.add(grp); }
                    break;
            }
        }
        return lista_filtrada;
        
    }

    /**
     * @param valor Conjunto de valores por los que se filtra.
     * @param filtro Opción elegida para filtrar
     * @param listaSinFiltrar Lista de todas las materias
     * @return Devuelve una lista filtrada
     * Método utilizado para filtrar las materias.
     */
    @Override
    public ArrayList<Materias> filtrarMaterias(String valor, String filtro, ArrayList<Materias> listaSinFiltrar) {

        ArrayList<Materias> lista_filtrada = new ArrayList<Materias>();

        switch (filtro) {
            case "DepartamentoMaterias":
                for (Materias mtr : listaSinFiltrar) {
                    if (mtr.getDepartamento().toLowerCase().contains(valor.toLowerCase())) {
                        lista_filtrada.add(mtr);
                    }
                }
                break;
            case "NombreMaterias":
                for (Materias mtr : listaSinFiltrar) {
                    if (mtr.getNombre().toLowerCase().contains(valor.toLowerCase())) {
                        lista_filtrada.add(mtr);
                    }
                }
                break;
            case "CodigoMaterias":
                for (Materias mtr : listaSinFiltrar) {
                    if (mtr.getCodigo_curso().toLowerCase().contains(valor.toLowerCase())) {
                        lista_filtrada.add(mtr);
                    }
                }
                break;

            case "IsoMaterias":
                for (Materias mtr : listaSinFiltrar) {
                    if (mtr.getIso().toLowerCase().contains(valor.toLowerCase())) {
                        lista_filtrada.add(mtr);
                    }
                }
                break;

        }
        return lista_filtrada;
    }

}
